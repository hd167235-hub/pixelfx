// Sound, made on the fly: no files. A little Web Audio synth plays a chime per school, a knock for each step,
// a wind that swells with the sea. Browser rules mean nothing sounds until the player touches the page.

export class Sound {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.lastStep = 0;
    this.ready = false;
    const start = () => this.start();
    addEventListener("pointerdown", start, { once: true });
    addEventListener("keydown", start, { once: true });
  }

  start() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.35;
    this.master.connect(this.ctx.destination);
    // a bed of wind: filtered noise, the level slowly wandering
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * 0.4;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const filt = this.ctx.createBiquadFilter();
    filt.type = "lowpass";
    filt.frequency.value = 380;
    this.wind = this.ctx.createGain();
    this.wind.gain.value = 0.05;
    src.connect(filt).connect(this.wind).connect(this.master);
    src.start();
    this.ready = true;
  }

  toggle() {
    this.enabled = !this.enabled;
    if (this.master) this.master.gain.value = this.enabled ? 0.35 : 0;
    return this.enabled;
  }

  tone(freq, dur = 0.2, type = "sine", gain = 0.2, slide = 0) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq * slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  noise(dur = 0.3, gain = 0.25, freq = 1200) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime, len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 2;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = freq;
    f.Q.value = 0.8;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
  }

  cast(spell) {
    if (!this.ctx) return;
    switch (spell.school) {
      case "fire": this.noise(0.5, 0.3, 700); this.tone(180, 0.3, "sawtooth", 0.12, 0.5); break;
      case "ice": this.tone(1400, 0.18, "triangle", 0.12, 1.4); this.tone(2100, 0.22, "sine", 0.08, 1.2); this.noise(0.2, 0.1, 4000); break;
      case "lightning": this.noise(0.35, 0.35, 2600); this.tone(90, 0.25, "square", 0.1, 0.6); break;
      case "holy": [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.tone(f, 0.3, "sine", 0.1), i * 55)); break;
      case "shadow": this.tone(120, 0.6, "sine", 0.18, 0.4); this.tone(180, 0.5, "triangle", 0.08, 0.5); break;
      case "nature": this.tone(392, 0.2, "triangle", 0.1); this.tone(587, 0.3, "sine", 0.08, 1.1); break;
      default: this.tone(660, 0.16, "triangle", 0.12, 1.6); this.noise(0.12, 0.08, 3000);
    }
  }

  select() { this.tone(880, 0.06, "square", 0.05); }
  blink() { this.tone(320, 0.18, "sawtooth", 0.1, 3); this.noise(0.15, 0.12, 2200); }
  chime() { [784, 1046, 1318, 1568].forEach((f, i) => setTimeout(() => this.tone(f, 0.7, "sine", 0.11), i * 120)); }

  /** Wind swells as the wizard runs, and hums low by the stones. */
  setAmbience(wizard) {
    if (!this.wind || !this.enabled) return;
    const k = 0.03 + Math.min(0.05, wizard.speed * 0.005);
    this.wind.gain.value += (k - this.wind.gain.value) * 0.05;
  }
}
