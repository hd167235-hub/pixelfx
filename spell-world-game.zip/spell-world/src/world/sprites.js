// The pixel sprites standing on the island, turned into three.js textures. The art itself is plain data in
// spriteData.js, so the offline preview tool paints exactly the same pixels.

import * as THREE from "three";
import { SPRITE_ROWS, SPRITE_PAL } from "./spriteData.js";

function canvas(w, h) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
}

/** Paint a char map into a canvas. */
function paint(rows, pal) {
  const w = rows[0].length, h = rows.length;
  const c = canvas(w, h), ctx = c.getContext("2d");
  const img = ctx.createImageData(w, h);
  rows.forEach((row, y) => {
    [...row].forEach((ch, x) => {
      if (ch === ".") return;
      const hex = pal[ch];
      if (!hex) return;
      const n = parseInt(hex.slice(1), 16), o = (y * w + x) * 4;
      img.data[o] = (n >> 16) & 255;
      img.data[o + 1] = (n >> 8) & 255;
      img.data[o + 2] = n & 255;
      img.data[o + 3] = 255;
    });
  });
  ctx.putImageData(img, 0, 0);
  return c;
}

/** A canvas to a nearest-neighbour texture. */
export function toTexture(c) {
  const t = new THREE.CanvasTexture(c);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function makeSpriteTexture() {
  const out = {};
  for (const [name, rows] of Object.entries(SPRITE_ROWS)) out[name] = toTexture(paint(rows, SPRITE_PAL[name]));
  return out;
}
