// pixelfx effects, standing up in the 3D world.
//
// Every effect in the library is a pure function of time that paints into a pixel frame (see src/fx). Here
// each cast gets its own frame and a canvas texture; the effect paints into the frame each tick, the texture
// is uploaded, and a camera-facing plane carries it into the scene. Additive layers (light/glow) go on a
// second plane with additive blending, so a fireball really does light up the meadow behind it.

import * as THREE from "three";
import { createFrame, clearFrame, createFx, painterFor, stockActor, actorAlphaOf, composite } from "../../../src/core/index.js";

// nearest-neighbour textures, sRGB, no mips: crisp pixels at any distance
function pixelTexture(canvas) {
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}


/**
 * A live effect in the scene.
 * mod: an effect module. at: THREE.Vector3 of the effect's anchor (its origin). opts: effect options plus
 * { scale, flip, hold, glow }.
 */
export function spawnEffect(scene, mod, at, opts = {}) {
  const meta = mod.meta ?? {};
  const [w, h] = meta.size ?? [64, 64];
  const [ox, oy] = meta.origin ?? [w / 2, h];
  const scale = opts.scale ?? 0.042;
  const factor = scale;
  const frame = createFrame(w, h);
  const img = new Uint8ClampedArray(w * h * 4);

  const colorCanvas = document.createElement("canvas");
  colorCanvas.width = w;
  colorCanvas.height = h;
  const cctx = colorCanvas.getContext("2d");
  const lightCanvas = document.createElement("canvas");
  lightCanvas.width = w;
  lightCanvas.height = h;
  const lctx = lightCanvas.getContext("2d");

  const colorTex = pixelTexture(colorCanvas);
  const lightTex = pixelTexture(lightCanvas);

  const pw = w * factor, ph = h * factor;
  const geo = new THREE.PlaneGeometry(pw, ph);
  // the anchor sits at (ox, oy) in frame pixels, measured from the frame's top left
  geo.translate((w / 2 - ox) * factor, (h / 2 - (h - oy)) * factor, 0);

  const colorMat = new THREE.MeshBasicMaterial({
    map: colorTex, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    blending: THREE.NormalBlending, toneMapped: false,
  });
  const colorMesh = new THREE.Mesh(geo, colorMat);
  const glowMat = new THREE.MeshBasicMaterial({
    map: lightTex, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending, toneMapped: false, opacity: opts.glow ?? 1,
  });
  const glowMesh = new THREE.Mesh(geo, glowMat);
  colorMesh.renderOrder = 12;
  glowMesh.renderOrder = 13;

  const group = new THREE.Group();
  group.position.copy(at);
  group.add(colorMesh, glowMesh);
  scene.add(group);

  const inst = createFx(mod, { x: ox, y: oy, flip: !!opts.flip, ...opts.opts, ...(opts.seed !== undefined ? { seed: opts.seed } : {}) });
  const actor = meta.actor ? opts.actor ?? stockActor(meta.actor === 2 ? 2 : 1) : null;
  const D = meta.duration ?? 1;
  let t = 0, age = 0, glowAcc = 0, dead = false;

  // paint the effect into the frame and upload it
  function render() {
    clearFrame(frame);
    inst.draw(frame, "back");
    inst.draw(frame, "front");
    composite(frame, img, null);
    cctx.putImageData(new ImageData(img, w, h), 0, 0);
    colorTex.needsUpdate = true;
    // the glow: the frame's additive buffer, brightened a touch
    const light = new Uint8ClampedArray(w * h * 4);
    for (let i = 0; i < w * h; i++) {
      const l = frame.light[i] & 0xffffff;
      light[i * 4] = l & 255;
      light[i * 4 + 1] = (l >>> 8) & 255;
      light[i * 4 + 2] = (l >>> 16) & 255;
      light[i * 4 + 3] = l ? 255 : 0;
    }
    lctx.putImageData(new ImageData(light, w, h), 0, 0);
    lightTex.needsUpdate = true;
  }
  render();

  const api = {
    mod,
    meta,
    group,
    get t() { return t; },
    get done() { return dead || t >= D + (opts.hold ?? 0); },
    stop() { inst.stop(); },
    setAnchor(v) { group.position.copy(v); },
    update(dt) {
      if (dead) return;
      age += dt;
      const step = 1 / 30;
      glowAcc += dt;
      while (glowAcc >= step && t < D + (opts.hold ?? 0)) {
        glowAcc -= step;
        t += step;
        inst.update(step);
      }
      if (glowAcc >= step) {
        inst.stop();
      }
      render();
      // fade out over the last breath of the effect
      const fade = Math.min(1, Math.max(0, (D + (opts.hold ?? 0.4) - t) / 0.4));
      colorMat.opacity = fade;
      glowMat.opacity = fade * (opts.glow ?? 1);
    },
    dispose() {
      dead = true;
      scene.remove(group);
      geo.dispose();
      colorMat.dispose();
      glowMat.dispose();
      colorTex.dispose();
      lightTex.dispose();
    },
  };
  return api;
}

/** A manager that owns effects and drops the finished ones. */
export class EffectPool {
  constructor(scene) {
    this.scene = scene;
    this.items = [];
    this.limit = 40;
  }
  spawn(mod, at, opts, flags = {}) {
    // a hard cap keeps a frantic player from melting the tab
    if (this.items.length >= this.limit && !flags.ambient) {
      const old = this.items.shift();
      old.dispose();
    }
    const fx = spawnEffect(this.scene, mod, at, opts);
    fx.ambient = !!flags.ambient;
    this.items.push(fx);
    return fx;
  }
  update(dt) {
    for (let i = this.items.length - 1; i >= 0; i--) {
      const fx = this.items[i];
      fx.update(dt);
      if (fx.done && !fx.ambient) {
        fx.dispose();
        this.items.splice(i, 1);
      }
    }
  }
  clear() {
    for (const fx of this.items) fx.dispose();
    this.items.length = 0;
  }
}

export { actorAlphaOf };
