// Things that live on the island: a little glowing slime that hops about the meadow, and a wisp drifting
// between the standing stones. Each is a pixelfx effect carried on a camera-facing billboard, moving along a
// wander of its own; spells can scare them, and they scarper.

import * as THREE from "three";
import * as slimeMod from "../../../src/fx/critters/slime.js";
import * as wispMod from "../../../src/fx/critters/wisp.js";
import { createFrame, createFx, composite } from "../../../src/core/index.js";
import { heightAt, walkable, SEA } from "./terrain.js";
import { mulberry32, range } from "./rng.js";

/** A pixelfx effect, drawn into a canvas texture so it can stand in the 3D world. */
function effectSprite(mod, opts, scale = 0.03) {
  const meta = mod.meta;
  const [w, h] = meta.size, [ox, oy] = meta.origin;
  const frame = createFrame(w, h);
  const img = new Uint8ClampedArray(w * h * 4);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  const geo = new THREE.PlaneGeometry(w * scale, h * scale);
  geo.translate((w / 2 - ox) * scale, (h / 2 - (h - oy)) * scale, 0);
  const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.35, depthWrite: true, side: THREE.DoubleSide, toneMapped: false });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.renderOrder = 9;
  const inst = createFx(mod, { x: ox, y: oy, ...opts });
  let last = 0;
  return {
    mesh,
    meta,
    update(t, camera) {
      // a plain effect stepped to absolute time (loops, so no drift)
      const step = 1 / 30;
      while (last + step <= t) {
        inst.update(step);
        last += step;
      }
      frame.color.fill(0);
      frame.light.fill(0);
      inst.draw(frame, "front");
      composite(frame, img, null);
      ctx.putImageData(new ImageData(img, w, h), 0, 0);
      tex.needsUpdate = true;
      mesh.rotation.y = Math.atan2(camera.position.x - mesh.position.x, camera.position.z - mesh.position.z);
    },
    dispose() {
      geo.dispose();
      mat.dispose();
      tex.dispose();
    },
  };
}

export class Wanderers {
  constructor(scene, world, cols) {
    this.world = world;
    this.scene = scene;
    const rnd = mulberry32(world.seed + 5);
    const f = world.features;
    this.items = [];

    // the slime: hops about a patch of meadow near the spawn
    for (let i = 0; i < 2; i++) {
      const sprite = effectSprite(slimeMod, { seed: Math.floor(rnd() * 9) + 1 }, 0.034);
      scene.add(sprite.mesh);
      this.items.push({
        kind: "slime",
        sprite,
        home: { x: f.spawn.x + range(rnd, -9, 9), z: f.spawn.z + range(rnd, -8, 3) },
        wander: 7,
        speed: 1.1,
        idle: range(rnd, 0, 2),
        target: null,
        pos: new THREE.Vector3(),
        hop: range(rnd, 0, 6),
        scared: 0,
      });
    }
    // the wisp: a slow light between the stones
    {
      const sprite = effectSprite(wispMod, { seed: 3 }, 0.05);
      scene.add(sprite.mesh);
      this.items.push({ kind: "wisp", sprite, home: { x: f.ring.x, z: f.ring.z }, wander: 5, speed: 0.7, idle: 1, target: null, pos: new THREE.Vector3(), scared: 0, float: true });
    }
    for (const it of this.items) {
      const y = Math.max(heightAt(world, it.home.x, it.home.z), SEA);
      it.pos.set(it.home.x, y, it.home.z);
    }
  }

  /** Something loud happened near (x, z): they run for home. */
  startle(x, z, radius = 9) {
    for (const it of this.items) {
      const d = Math.hypot(it.pos.x - x, it.pos.z - z);
      if (d < radius) {
        it.scared = 2.2;
        it.target = { x: it.home.x + (it.pos.x - x) * 0.4, z: it.home.z + (it.pos.z - z) * 0.4 };
        // a little hop of surprise
        it.hop = 0.4;
      }
    }
  }

  update(dt, t, camera) {
    const rnd = Math.random;
    for (const it of this.items) {
      it.idle -= dt;
      it.scared = Math.max(0, it.scared - dt);
      // pick a new place to wander to now and then
      if (!it.target && it.idle <= 0) {
        for (let k = 0; k < 8; k++) {
          const a = rnd() * Math.PI * 2, r = rnd() * it.wander;
          const x = it.home.x + Math.cos(a) * r, z = it.home.z + Math.sin(a) * r;
          if (walkable(this.world, x, z)) {
            it.target = { x, z };
            break;
          }
        }
        it.idle = 1.5 + rnd() * 2.5;
      }
      if (it.target) {
        const dx = it.target.x - it.pos.x, dz = it.target.z - it.pos.z;
        const d = Math.hypot(dx, dz);
        if (d < 0.15) it.target = null;
        else {
          const v = it.speed * (it.scared > 0 ? 2.6 : 1) * dt;
          const nx = it.pos.x + (dx / d) * v, nz = it.pos.z + (dz / d) * v;
          if (walkable(this.world, nx, nz)) {
            it.pos.x = nx;
            it.pos.z = nz;
          } else it.target = null;
        }
      }
      // sit on the ground; the slime hops, the wisp floats
      const ground = Math.max(heightAt(this.world, it.pos.x, it.pos.z), SEA);
      it.hop = Math.max(0, it.hop - dt * (it.scared > 0 ? 2.4 : 1.2));
      const bob = it.float ? 1.4 + Math.sin(t * 1.3 + it.home.x) * 0.35 : Math.abs(Math.sin(t * 5 + it.home.z)) * 0.28 + it.hop;
      it.pos.y += (ground + bob - it.pos.y) * Math.min(1, dt * 12);
      it.sprite.mesh.position.copy(it.pos);
      if (it.kind === "wisp") it.sprite.mesh.position.y += 1.1;
      it.sprite.update(t, camera);
    }
  }

  dispose() {
    for (const it of this.items) {
      this.scene.remove(it.sprite.mesh);
      it.sprite.dispose();
    }
    this.items.length = 0;
  }
}
