SPELL WORLD - game phieu luu phep thuat (pixelfx)

Cach choi:
1. Giai nen file ZIP nay.
2. Mo thu muc spell-world.
3. Mo file index.html bang trinh duyet (Chrome/Edge/Firefox).

Dieu khien co ban:
- Chuot: keo de xoay camera, cuon de zoom, click de niem phep.
- Phim 1-6: phep co ban. Shift+1..0: phep manh. Q/W/E/R/T/A/S/D/F/G/H/Z/X/C: cac phep dac biet.
- B: mo sach phep. H: tro giup.

Ghi chu: game chay offline, khong can mang (font Google neu khong co mang se tu dung font mac dinh).
