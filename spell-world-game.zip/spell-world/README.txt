SPELL WORLD - Dao Phep Thuat

BAN HTML DON FILE:
Mo spell-world.html trong trinh duyet. File nay can WebGL; neu mo bang trinh duyet dien thoai ma file:// khong cho phep WebGL, hay mo bang Chrome hoac Firefox va cho phep WebGL.

BAN THU MUC:
Giai nen thu muc spell-world, sau do chay server local trong thu muc do:
  python -m http.server 8000
Mo http://localhost:8000/ trong trinh duyet.

Dieu khien:
- Keo chuot/cham va keo: xoay camera.
- Cuon/pinch: zoom.
- Click/cham: niem phep vao tam ngắm.
- WASD: di chuyen; Shift: chay; Space: blink.
- 1-6: chon phep co ban; B mo sach phep; H mo tro giup.
