// Everything standing on the island: pines, rocks, bushes, a ring of standing stones, the shrine the wizard
// wakes up beside, a campfire, reeds by the water. Props are drawn as pixel sprites that always face the
// camera, standing on the ground at their tile's height — the same trick the land itself uses.

import * as THREE from "three";
import { N, SEA, M, heightAt, matAt } from "./terrain.js";
import { mulberry32, range, hash2 } from "./rng.js";
import { makeSpriteTexture } from "./sprites.js";

const GRASS_OK = (m) => m === M.GRASS || m === M.DIRT || m === M.SNOW;

/** A billboard sprite: { mesh, x, y, z } that turns with the camera. */
// props are plain planes with their own material, so the world can be torn down and rebuilt from a new seed
function billboard(tex, world, w, h, z = 0) {
  const geo = new THREE.PlaneGeometry(w, h);
  geo.translate(0, h / 2, 0);
  const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.4, side: THREE.DoubleSide, depthWrite: true, toneMapped: false });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.copy(world);
  mesh.renderOrder = z;
  mesh.userData.own = true;
  return mesh;
}
export { billboard };

/** Turn every prop to face the camera once per frame. */
export function faceSprites(sprites, camera) {
  for (const s of sprites) {
    if (s.billboard) {
      s.mesh.rotation.y = Math.atan2(camera.position.x - s.mesh.position.x, camera.position.z - s.mesh.position.z);
    }
  }
}

export function makeDressing(scene, world, cols) {
  const rnd = mulberry32(world.seed + 77);
  const sprites = [];
  const group = new THREE.Group();
  scene.add(group);
  const tex = makeSpriteTexture();
  const f = world.features;

  // ---- trees: a pine on the grass, thinner and paler as it climbs
  const treeTex = [tex.pine1, tex.pine2, tex.pine3];
  const rockTex = [tex.rock1, tex.rock2];
  const bushTex = [tex.bush, tex.reeds];
  let planted = 0;
  for (let z = 2; z < N - 2; z++) {
    for (let x = 2; x < N - 2; x++) {
      const m = matAt(world, x, z);
      const h = cols.top[world.idx(x, z)];
      if (!GRASS_OK(m) || h < SEA + 1) continue;
      // keep the landmark clearings clear
      const clear = Math.min(
        Math.hypot(x - f.spawn.x, z - f.spawn.z) - 10,
        Math.hypot(x - f.ring.x, z - f.ring.z) - 7,
        Math.hypot(x - f.shrine.x, z - f.shrine.z) - 5,
        Math.hypot(x - f.camp.x, z - f.camp.z) - 3,
      );
      if (clear < 0) continue;
      // don't crowd the paths
      let nearPath = false;
      for (let dz = -2; dz <= 2 && !nearPath; dz++) for (let dx = -2; dx <= 2 && !nearPath; dx++) if (matAt(world, x + dx, z + dz) === M.PATH) nearPath = true;
      const r = rnd();
      const forest = 0.032 + 0.075 * hash2(x >> 2, z >> 2, world.seed);   // clumped woods, not an even sprinkle
      if (!nearPath && r < forest && h > SEA + 2) {
        const k = m === M.SNOW ? 2 : r < forest * 0.3 ? 0 : 1;
        const s = 0.72 + rnd() * 0.42;
        const mesh = billboard(treeTex[k], new THREE.Vector3(x + 0.5 + range(rnd, -0.25, 0.25), h - 0.2, z + 0.5 + range(rnd, -0.25, 0.25)), 1.85 * s, 3.05 * s, 5);
        mesh.userData.billboard = true;
        group.add(mesh);
        sprites.push({ mesh, billboard: true });
        planted++;
      } else if (r < forest + 0.035 && h < SEA + 9) {
        const s = 0.5 + rnd() * 0.5;
        const m2 = billboard(rockTex[rnd() < 0.5 ? 0 : 1], new THREE.Vector3(x + 0.5, h - 0.1, z + 0.5), 1.1 * s, 0.9 * s, 4);
        m2.userData.billboard = true;
        group.add(m2);
        sprites.push({ mesh: m2, billboard: true });
      } else if (r < forest + 0.06 && h < SEA + 14) {
        const s = 0.7 + rnd() * 0.4;
        const m3 = billboard(bushTex[0], new THREE.Vector3(x + 0.5, h - 0.1, z + 0.5), 1.2 * s, 0.8 * s, 4);
        m3.userData.billboard = true;
        group.add(m3);
        sprites.push({ mesh: m3, billboard: true });
      }
    }
  }
  // reeds along the beaches, in loose clumps
  for (let z = 1; z < N - 1; z++)
    for (let x = 1; x < N - 1; x++) {
      const g = world.heights[world.idx(x, z)];
      if (g > SEA) continue;
      if (matAt(world, x, z) !== M.SAND || rnd() > 0.16) continue;
      const m = billboard(tex.reeds, new THREE.Vector3(x + 0.5, SEA - 0.35, z + 0.5), 1.1, 1.0, 4);
      m.userData.billboard = true;
      group.add(m);
      sprites.push({ mesh: m, billboard: true });
    }

  // ---- the ring of standing stones, with runes waiting to be lit
  const ringStones = [];
  {
    const R = f.ring.radius + 1.4;
    const count = 9;
    for (let k = 0; k < count; k++) {
      const a = (k / count) * Math.PI * 2;
      const sx = f.ring.x + Math.cos(a) * R, sz = f.ring.z + Math.sin(a) * R;
      const sy = cols.top[world.idx(Math.round(sx), Math.round(sz))];
      const m = billboard(tex.menhir, new THREE.Vector3(sx, sy - 0.3, sz), 1.15, 2.45 + (k % 3) * 0.18, 6);
      m.userData.billboard = true;
      group.add(m);
      sprites.push({ mesh: m, billboard: true });
      ringStones.push({ x: sx, y: sy, z: sz, k });
    }
  }

  // ---- the shrine: a small arch of stones on the west shore, where the wizard has washed up
  const shrineLights = [];
  {
    const { x, z } = f.shrine, y = cols.top[world.idx(x, z)];
    const a = billboard(tex.shrine, new THREE.Vector3(x + 0.5, y - 0.2, z + 0.5), 2.6, 3.2, 6);
    a.userData.billboard = true;
    group.add(a);
    sprites.push({ mesh: a, billboard: true });
    const gl = new THREE.PointLight(0x7fe6ff, 6, 9, 2);
    gl.position.set(x + 0.5, y + 2.1, z + 0.5);
    group.add(gl);
    shrineLights.push(gl);
  }

  // ---- the campfire: a ring of stones, and a point light that breathes
  const campLight = new THREE.PointLight(0xff9a4a, 9, 14, 2);
  {
    const { x, z } = f.camp, y = cols.top[world.idx(x, z)];
    const b = billboard(tex.campfire, new THREE.Vector3(x + 0.5, y - 0.1, z + 0.5), 2.2, 1.6, 6);
    b.userData.billboard = true;
    group.add(b);
    sprites.push({ mesh: b, billboard: true });
    campLight.position.set(x + 0.5, y + 1.2, z + 0.5);
    group.add(campLight);
    const tent = billboard(tex.tent, new THREE.Vector3(x + 3.6, y - 0.2, z + 1.4), 2.6, 2.0, 6);
    tent.userData.billboard = true;
    group.add(tent);
    sprites.push({ mesh: tent, billboard: true });
  }

  // ---- the portal gate on the east beach, waiting for the player to find it
  const gateTile = { x: f.spawn.x + 8, z: f.spawn.z - 4 };
  const gate = { pos: new THREE.Vector3(gateTile.x + 0.5, cols.top[world.idx(gateTile.x, gateTile.z)], gateTile.z + 0.5) };
  {
    const g = billboard(tex.gate, gate.pos.clone().add(new THREE.Vector3(0, -0.15, 0)), 2.3, 2.9, 6);
    g.userData.billboard = true;
    group.add(g);
    sprites.push({ mesh: g, billboard: true });
  }

    return {
    group,
    sprites,
    ringStones,
    gate,
    update(t) {
      faceSprites(sprites, arguments[1] ?? { position: new THREE.Vector3() });
      campLight.intensity = 8 + Math.sin(t * 7.3) * 1.6 + Math.sin(t * 13.1) * 0.8;
      for (let i = 0; i < shrineLights.length; i++) shrineLights[i].intensity = 5 + Math.sin(t * 2.1 + i) * 1.5;
    },
  };
}
