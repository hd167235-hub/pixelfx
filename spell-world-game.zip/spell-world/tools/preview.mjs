#!/usr/bin/env node
// A software preview of the island, for checking the composition without a GPU.
//
// It doesn't run three.js or GLSL. It rebuilds the same terrain and the same column data the browser uses,
// then projects every column's billboard and top face into a PNG: a software version of land.js's look, plus
// the pines, the stones, the camp, the gate and the wizard. What you see here is the map the browser is given,
// checked from the camera's side. (Look and lighting in the browser are done in the shaders; this is geometry
// and composition.)
//
//   node tools/preview.mjs [--seed 1337] [--yaw 0.62] [--pitch 0.36] [--dist 21] [--out ../docs/readme/spell-world.png]

import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { encodePNG } from "../../tools/lib/png.mjs";
import { makeWorld, N, SEA, M, heightAt, matAt } from "../src/world/terrain.js";
import { makeColumns, rampOf } from "../src/world/columns.js";
import { SPRITE_ROWS, SPRITE_PAL } from "../src/world/spriteData.js";
import { mulberry32, hash2 } from "../src/world/rng.js";
import { magePixels } from "../src/player/mage.js";

const HERE = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const arg = (name, def) => {
  const i = args.indexOf("--" + name);
  return i >= 0 ? Number(args[i + 1]) : def;
};
const crop = (() => { const i = args.indexOf("--crop"); return i >= 0 ? args[i + 1].split(",").map(Number) : null; })();
const out = (() => {
  const i = args.indexOf("--out");
  return i >= 0 ? resolve(args[i + 1]) : join(HERE, "..", "preview.png");
})();
const seed = arg("seed", 1337);
const yaw = arg("yaw", 1.45), pitch = arg("pitch", 0.38), dist = arg("dist", 22);
const W = arg("w", 1280), H = arg("h", 720);
const nofig = args.includes("--nofig");
const debug = args.includes("--debug");
const only = (() => { const i = args.indexOf("--only"); return i >= 0 ? args[i + 1] : null; })();
const norim = args.includes("--norim");
const time = arg("t", 0);

const hexNum = (h) => {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const clamp = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
// the palettes are 0..1 floats (the shaders want that); this preview works in 0..255
const ramp255 = (mat) => rampOf(mat).map((c) => c.map((v) => v * 255));
const rampAt = (ramp, t) => ramp[Math.round(clamp(t) * (ramp.length - 1))];

// ---- the frame. Two depths: the distance for props drawn as sprites, and a tile depth (in tiles) for the
// land, which is exact to the pixel because it comes from the camera ray, not from a triangle's corners.
const buf = new Float32Array(W * H * 3);
const depth = new Float32Array(W * H).fill(Infinity);
const tdepth = new Float32Array(W * H).fill(-1e9);
const put = (x, y, c) => {
  if (x < 0 || y < 0 || x >= W || y >= H) return;
  const o = (y * W + x) * 3;
  buf[o] = c[0] / 255;
  buf[o + 1] = c[1] / 255;
  buf[o + 2] = c[2] / 255;
};

// ---- the camera: a perspective camera looking at the wizard, at a low raking pitch
const world = makeWorld(seed);
const cols = makeColumns(world);
const f = world.features;
const eye = [f.spawn.x + Math.sin(yaw) * Math.cos(pitch) * dist, f.spawn.y + 3.2 + Math.sin(pitch) * dist, f.spawn.z + Math.cos(yaw) * Math.cos(pitch) * dist];
const at = [f.spawn.x, f.spawn.y + 1.1, f.spawn.z];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const norm = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const fwd = norm(sub(at, eye));
const right = norm(cross(fwd, [0, 1, 0]));
const up = cross(right, fwd);
const FOV = 40, focal = H / 2 / Math.tan((FOV * Math.PI) / 360);
const project = (p) => {
  const d = sub(p, eye), z = dot(d, fwd);
  if (z <= 0.2) return null;
  return { x: W / 2 + (dot(d, right) / z) * focal, y: H / 2 - (dot(d, up) / z) * focal, z: Math.hypot(...d) };
};

const tileTop = (x, z) => cols.top[world.idx(Math.min(N - 1, Math.max(0, Math.round(x))), Math.min(N - 1, Math.max(0, Math.round(z))))];
const camRight = [right[0], right[2]];
const crLen = Math.hypot(...camRight) || 1;
const crX = camRight[0] / crLen, crZ = camRight[1] / crLen;

// ---- the sky
const SKY = { top: hexNum("#0a0d24"), mid: hexNum("#3a2a63"), low: hexNum("#a2506b"), glow: hexNum("#ffb16b"), sun: hexNum("#ffd9a0") };
const sunDir = norm([-0.55, 0.07, -0.83]);
const moonDir = norm([0.45, 0.55, 0.7]);
for (let y = 0; y < H; y++) {
  const ndc = (H / 2 - y) / focal;
  for (let x = 0; x < W; x++) {
    const t = (x - W / 2) / focal;
    const d = norm([fwd[0] + right[0] * t + up[0] * ndc, fwd[1] + right[1] * t + up[1] * ndc, fwd[2] + right[2] * t + up[2] * ndc]);
    let c = mix(SKY.low, SKY.mid, clamp((d[1] - 0.0) / 0.34));
    c = mix(c, SKY.top, clamp((d[1] - 0.22) / 0.73));
    const sd = Math.max(0, dot(d, sunDir));
    c = c.map((v, i) => v + SKY.glow[i] * Math.pow(sd, 6) * 0.75 + SKY.sun[i] * Math.pow(sd, 90) * 1.4);
    if (d[1] < 0.06) c = mix(c, SKY.low.map((v) => v * 0.65), clamp((0.06 - d[1]) / 0.28));
    const md = dot(d, moonDir);
    if (md > 0.9975) c = mix(c, [255, 240, 209], 0.95);
    if (d[1] > 0.06) {
      const gx = Math.floor(Math.atan2(d[2], d[0]) * 60), gy = Math.floor(d[1] * 90);
      const r = hash2(gx, gy, 7);
      if (r > 0.985) { const tw = 0.55 + 0.45 * Math.sin(time * 3 + r * 40); c = c.map((v) => Math.min(255, v + 230 * tw * 0.5 * clamp((d[1] - 0.08) / 0.32))); }
    }
    c = c.map((v) => Math.round(v));
    put(x, y, c);
  }
}

// ---- the look: turns a column's face into a colour, the way land.js's shader does (roughly)
function wallColor(mat, top, y, x, z, jitter, shore, distK, drop = 0) {
  // cliff profile: surface material, soil, then stone at the foot
  const ramp = ramp255(mat);
  const band = Math.floor(y);
  const inBand = y - band;
  const seam = clamp(inBand / 0.09) * clamp((1 - inBand) / 0.12);
  const level = drop * clamp((top - SEA) / 22);
  let col = rampAt(ramp, 1 - level);
  const n = (Math.sin(band * 12.9898 + x * 3.1) * 43758.5453) % 1;
  const k = 0.86 + 0.16 * Math.abs(n);
  col = col.map((v) => v * k);
  col = mix(col, col.map((v) => v * 0.62), (1 - seam) * 0.55);
  if (inBand > 0.78) col = col.map((v) => v * 1.1);
  col = col.map((v) => v * 0.82);
  const lip = 1 - inBand;
  if (mat > 2.5 && mat < 4.5 && lip < 0.3 + 0.12 * jitter) col = rampAt(ramp, 1).map((v) => v * (1.05 + 0.1 * jitter));
  if (mat > 4.5 && lip < 0.18) col = rampAt(ramp, 1).map((v) => v * 1.05);
  if (shore > 0.5) col = mix(col, rampAt(ramp255(M.SAND), 1 - clamp(drop)), 0.85);
  col = col.map((v) => v * (0.74 + 0.26 * clamp(1 - drop)));
  return hazed(col, distK);
}
function topColor(mat, x, z, top, lipS, lipN, lipE, lipW, jitter, distK, uu = 0.5, vv = 0.5) {
  const ramp = ramp255(mat);
  let col = rampAt(ramp, 0.94).map((v) => v);
  const d = (Math.floor(x * 2) + Math.floor(z * 2) * 2) % 4;
  col = col.map((v) => v * (0.94 + 0.12 * (d / 3)));
  let edge = false;
  if ((lipS && vv > 0.95) || (lipN && vv < 0.05) || (lipE && uu > 0.95) || (lipW && uu < 0.05)) edge = true;
  if (edge && !norim) col = mix(col, rampAt(ramp255(M.DIRT), 0.5).map((v) => v * 0.72), 0.6);
  if (mat > 4.5) col = mix(col, rampAt(ramp, 1), 0.25 + 0.2 * jitter);
  return hazed(col, distK);
}
const FOG = [74, 53, 85], SKYL = [162, 80, 107];
function hazed(col, distK) {
  const k = clamp((distK - 55) / 155) * 0.85;
  const fog = mix(FOG, SKYL, 0.3 + 0.4 * clamp((distK - 80) / 240));
  return mix(col, fog, k);
}

// ---- painting: triangles with no depth test. The caller draws far to near (see the island below).
const paintTri = (p0, p1, p2, depthFn, colorFn) => {
  if (!p0 || !p1 || !p2) return;
  // one pixel of slack all round: a pixel whose centre is a hair outside the edge still belongs to the
  // triangle, and without this the ground and its own cliff leave a hairline gap along the shared edge
  const minX = Math.max(0, Math.floor(Math.min(p0.x, p1.x, p2.x)) - 1);
  const maxX = Math.min(W - 1, Math.ceil(Math.max(p0.x, p1.x, p2.x)) + 1);
  const minY = Math.max(0, Math.floor(Math.min(p0.y, p1.y, p2.y)) - 1);
  const maxY = Math.min(H - 1, Math.ceil(Math.max(p0.y, p1.y, p2.y)) + 1);
  const e = (a, b, px, py) => (b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x);
  const sgn = e(p0, p1, p2.x, p2.y) >= 0 ? 1 : -1;
  for (let y = minY; y <= maxY; y++)
    for (let x = minX; x <= maxX; x++) {
      const px = x + 0.5, py = y + 0.5;
      if (sgn * e(p1, p2, px, py) < -0.5 || sgn * e(p2, p0, px, py) < -0.5 || sgn * e(p0, p1, px, py) < -0.5) continue;
      depth[y * W + x] = depthFn(px, py);
      put(x, y, colorFn(px, py));
    }
};
const paintQuad = (a, b, c, d, depthFn, colorFn) => {
  paintTri(a, b, c, depthFn, colorFn);
  paintTri(a, c, d, depthFn, colorFn);
};

// ---- draw the island.
//
// Real side walls, like land.js: a wall is drawn on a tile's edge only where the neighbour across that edge is
// lower. Painting far-to-near, wall first and then the flat top, keeps nearer ground in front of the cliffs
// behind it without needing a depth buffer.

const order = [];
for (let z = 0; z < N; z++) for (let x = 0; x < N; x++) order.push([x, z]);
order.sort((p, q) => Math.hypot(q[0] + 0.5 - eye[0], q[1] + 0.5 - eye[2]) - Math.hypot(p[0] + 0.5 - eye[0], p[1] + 0.5 - eye[2]));

for (const [x, z] of order) {
  const i = world.idx(x, z);
  const top = cols.top[i], mat = cols.mat[i], bot = cols.bottom[i];
  const dd = Math.hypot(x + 0.5 - eye[0], z + 0.5 - eye[2]);

  // ---- its side walls, only where the ground drops across that edge. Drawn before the flat top, so the
  // top's own pixels (the grass lip) cover the wall's last row where the two meet.
  if (only !== 'tops') {
    const nb = [cols.hN[i], cols.hS[i], cols.hE[i], cols.hW[i]];
    const edges = [
      [[x, z], [x + 1, z]],             // north
      [[x + 1, z + 1], [x, z + 1]],     // south
      [[x + 1, z], [x + 1, z + 1]],     // east
      [[x, z + 1], [x, z]],             // west
    ];
    for (let d = 0; d < 4; d++) {
      const foot = nb[d];
      if (top - foot <= 0.4) continue;
      const [a, b] = edges[d];
      const pA = project([a[0], top, a[1]]), pB = project([b[0], top, b[1]]);
      const pC = project([b[0], foot, b[1]]), pD = project([a[0], foot, a[1]]);
      if (!pA || !pB || !pC || !pD) continue;
      const yLip = (pA.y + pB.y) / 2, yFoot = (pD.y + pC.y) / 2;
      paintQuad(pA, pB, pC, pD, () => dd, (px, py) => {
        const tTop = clamp((py - yLip) / Math.max(1e-3, yFoot - yLip));   // 0 at the lip, 1 at the foot
        const y = top + tTop * (foot - top);
        if (debug) return [mat * 28, 60, 60 + (Math.floor(y) % 3) * 60];
        return wallColor(mat, top, y, x, z, cols.jitter[i], cols.shore[i], dd, tTop);
      });
    }
  }

  // ---- the flat top
  if (only !== 'walls' && mat >= 1.5) {
    const T = [[x, z], [x + 1, z], [x + 1, z + 1], [x, z + 1]].map(([cx, cz]) => project([cx, top, cz]));
    if (T.every(Boolean)) {
      const lipS = cols.hS[i] < top - 0.5, lipN = cols.hN[i] < top - 0.5, lipE = cols.hE[i] < top - 0.5, lipW = cols.hW[i] < top - 0.5;
      const paint = (px, py) => {
        if (debug) { const v = Math.round((top / 36) * 255); return [40 + v * 0.6, 255 - v * 0.7, 60 + v * 0.3]; }
        // where the pixel falls on the tile, from the ray's own landing point
        const t = 1 / focal;
        const dx = fwd[0] + right[0] * (px - W / 2) * t + up[0] * (H / 2 - py) * t;
        const dy = fwd[1] + right[1] * (px - W / 2) * t + up[1] * (H / 2 - py) * t;
        const dz = fwd[2] + right[2] * (px - W / 2) * t + up[2] * (H / 2 - py) * t;
        const tt = (top - eye[1]) / (dy || -1e-6);
        const wx = eye[0] + dx * tt, wz = eye[2] + dz * tt;
        return topColor(mat, x, z, top, lipS, lipN, lipE, lipW, cols.jitter[i], dd, clamp(wx - x), clamp(wz - z));
      };
      for (const [k0, k1, k2] of [[0, 1, 2], [0, 2, 3]]) paintTri(T[k0], T[k1], T[k2], () => dd, paint);
    }
  }
}

// ---- the sea: a flat plane at SEA level, with surf near the shore
for (let y = 0; y < H; y++)
  for (let x = 0; x < W; x++) {
    const i = y * W + x;
    const px = x + 0.5, py = y + 0.5;
    // where does this pixel's ray meet y = SEA?
    const d = norm([fwd[0] + right[0] * ((x - W / 2) / focal) + up[0] * ((H / 2 - y) / focal), fwd[1] + right[1] * ((x - W / 2) / focal) + up[1] * ((H / 2 - y) / focal), fwd[2] + right[2] * ((x - W / 2) / focal) + up[2] * ((H / 2 - y) / focal)]);
    if (d[1] >= -0.0005) continue;
    const t = (SEA - eye[1]) / d[1];
    if (t <= 0) continue;
    const wx = eye[0] + d[0] * t, wz = eye[2] + d[2] * t;
    const zt = t;
    if (zt >= depth[i]) continue;
    const nl = heightAt(world, wx, wz);
    if (nl > SEA - 0.05 && Math.hypot(wx - N / 2, wz - N / 2) < N * 0.62) continue;   // dry land: no water here
    const land = Math.max(nl, SEA);
    const depthK = clamp((SEA - land) / 4.5);        // 0 at the waterline, 1 in deep water
    const shallow = 1 - depthK;
    const water = ramp255(M.WATER);
    let col = mix(rampAt(water, 3), rampAt(water, 0), depthK);
    const w = Math.sin(wx * 0.55 + time) * 0.5 + Math.sin(wz * 0.73 - time * 0.9) * 0.35 + Math.sin((wx + wz) * 1.1 + time * 1.7) * 0.18;
    col = mix(col, rampAt(water, 4).map((v) => v * 1.15), clamp(w) * 0.35 * (1 - depthK));
    const beach = clamp((SEA + 1.2 - land) / 0.85);
    const surf = clamp(1 - Math.abs(beach - 0.55 - w * 0.12) / 0.06);
    if (surf > 0) col = mix(col, [158, 219, 235], surf * 0.85);
    const sparkle = hash2(Math.floor(wx * 12), Math.floor(wz * 12) + Math.floor(time * 3), 3);
    if (sparkle > 0.92 && w > -0.2) col = mix(col, [200, 240, 250], 0.5);
    col = mix(col, [22, 40, 62], 0.4);
    col = hazed(col, (40 + zt * 0.9) * 0.9);
    depth[i] = zt;
    put(x, y, col);
  }

// ---- props and the wizard, as billboards
function sprite(name, pos, w, h) {
  const rows = SPRITE_ROWS[name], pal = SPRITE_PAL[name];
  if (!rows || only) return;
  const sw = rows[0].length, sh = rows.length;
  // the sprite stands on pos, w wide in world units
  for (let sy = 0; sy < sh; sy++)
    for (let sx = 0; sx < sw; sx++) {
      const ch = rows[sy][sx];
      if (ch === "." || ch === " ") continue;
      const hex = pal[ch];
      if (!hex) continue;
      const u = (sx + 0.5) / sw, v = (sy + 0.5) / sh;
      const p = [pos[0] + (u - 0.5) * w, pos[1] + (1 - v) * h, pos[2]];
      const q = project(p);
      if (!q) continue;
      const size = Math.max(1, Math.round((w / sw) * (focal / q.z)));
      const zt = q.z;
      for (let oy = 0; oy < size; oy++)
        for (let ox = 0; ox < size; ox++) {
          const px = Math.round(q.x) + ox - (size >> 1), py = Math.round(q.y) + oy - (size >> 1);
          if (px < 0 || py < 0 || px >= W || py >= H) continue;
          const i = py * W + px;
          if (zt > depth[i] + 0.6) continue;
          depth[i] = zt;
          put(px, py, hexNum(hex));
        }
    }
}

// the same scatter dressing.js does
const rnd = mulberry32(seed + 77);
for (let z = 2; z < N - 2; z++)
  for (let x = 2; x < N - 2; x++) {
    const m = world.mats[world.idx(x, z)], h = world.heights[world.idx(x, z)];
    if (!(m === M.GRASS || m === M.DIRT || m === M.SNOW) || h < SEA + 1) continue;
    const clear = Math.min(
      Math.hypot(x - f.spawn.x, z - f.spawn.z) - 3,
      Math.hypot(x - f.ring.x, z - f.ring.z) - 7,
      Math.hypot(x - f.shrine.x, z - f.shrine.z) - 5,
      Math.hypot(x - f.camp.x, z - f.camp.z) - 3,
    );
    if (clear < 0) continue;
    let nearPath = false;
    for (let dz = -2; dz <= 2 && !nearPath; dz++) for (let dx = -2; dx <= 2 && !nearPath; dx++) if (matAt(world, x + dx, z + dz) === M.PATH) nearPath = true;
    const r = rnd();
    const forest = 0.032 + 0.075 * hash2(x >> 2, z >> 2, seed);
    const distK = Math.hypot(x - eye[0], z - eye[2]);
    if (!nearPath && r < forest && h > SEA + 2) {
      const k = m === M.SNOW ? "pine3" : r < forest * 0.3 ? "pine1" : "pine2";
      const s = 0.85 + rnd() * 0.55;
      sprite(k, [x + 0.5, cols.top[world.idx(x, z)], z + 0.5], 1.85 * s, 3.05 * s);
    } else if (r < forest + 0.035 && h < SEA + 9) {
      rnd();
      sprite(rnd() < 0.5 ? "rock1" : "rock2", [x + 0.5, cols.top[world.idx(x, z)], z + 0.5], 1.1, 0.9);
    } else if (r < forest + 0.06 && h < SEA + 14) {
      rnd();
      sprite("bush", [x + 0.5, cols.top[world.idx(x, z)], z + 0.5], 1.2, 0.8);
    }
  }
// the ring, the shrine, the camp, the gate
const RING = f.ring.radius + 1.4;
for (let k = 0; k < 9; k++) {
  const a = (k / 9) * Math.PI * 2;
  const sx = f.ring.x + Math.cos(a) * RING, sz = f.ring.z + Math.sin(a) * RING;
  sprite("menhir", [sx, tileTop(sx, sz), sz], 1.15, 2.45 + (k % 3) * 0.18);
}
sprite("shrine", [f.shrine.x + 0.5, tileTop(f.shrine.x, f.shrine.z), f.shrine.z + 0.5], 2.6, 3.2);
sprite("campfire", [f.camp.x + 0.5, tileTop(f.camp.x, f.camp.z), f.camp.z + 0.5], 2.2, 1.6);
sprite("tent", [f.camp.x + 4.1, tileTop(f.camp.x + 4, f.camp.z + 1), f.camp.z + 1.4], 2.6, 2.0);
const gate = [f.spawn.x + 8.5, tileTop(f.spawn.x + 8.5, f.spawn.z - 4), f.spawn.z - 4];
sprite("gate", gate, 2.3, 2.9);

if (!nofig) {
  // the wizard, from his own pixels
  const mage = magePixels("stand");
  const SCALE = 0.055;
  const feet = [f.spawn.x, f.spawn.y, f.spawn.z];
  for (let y = 0; y < mage.h; y++)
    for (let x = 0; x < mage.w; x++) {
      const o = (y * mage.w + x) * 4;
      if (!mage.rgba[o + 3]) continue;
      const wx = feet[0] + (x - mage.ox) * SCALE;
      const wy = feet[1] + (mage.oy - y) * SCALE;
      const q = project([wx, wy, feet[2]]);
      if (!q) continue;
      // a source pixel covers a block on screen: fill the whole block, so he never comes out stippled
      const size = Math.max(1, Math.ceil(SCALE * (focal / q.z)));
      const px0 = Math.round(q.x - size / 2), py0 = Math.round(q.y - size / 2);
      for (let oy = 0; oy < size; oy++)
        for (let ox = 0; ox < size; ox++) {
          const px = px0 + ox, py = py0 + oy;
          if (px < 0 || py < 0 || px >= W || py >= H) continue;
          const i = py * W + px;
          if (q.z > depth[i] + 0.6) continue;
          depth[i] = q.z;
          put(px, py, [mage.rgba[o], mage.rgba[o + 1], mage.rgba[o + 2]]);
        }
    }
}

// ---- a moonlit vignette, and out to PNG
const [CX, CY, CW, CH] = crop ?? [0, 0, W, H];
const OW = crop ? CW : W, OH = crop ? CH : H;
const rgba = Buffer.alloc(OW * OH * 4);
for (let y = 0; y < OH; y++)
  for (let x = 0; x < OW; x++) {
    const sx = x + CX, sy = y + CY;
    const i = sy * W + sx, o = (y * OW + x) * 4;
    if (sx < 0 || sy < 0 || sx >= W || sy >= H) { rgba[o + 3] = 255; continue; }
    const vx = (sx / W - 0.5) * 1.6, vy = (sy / H - 0.5) * 1.6;
    const k = 1 - clamp(Math.hypot(vx, vy) * 0.42) ** 2 * 0.55;
    rgba[o] = clamp(buf[i * 3] * k) * 255;
    rgba[o + 1] = clamp(buf[i * 3 + 1] * k) * 255;
    rgba[o + 2] = clamp(buf[i * 3 + 2] * k) * 255;
    rgba[o + 3] = 255;
  }
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, encodePNG(OW, OH, rgba));
console.log("wrote", out, `${OW}x${OH}`, "seed", seed);
