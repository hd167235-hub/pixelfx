// The spellbar's icons. Each one is a tiny live pixelfx effect played in a 40x40 canvas — the same code the
// world runs, thumbnailed — so the bar shows the spells themselves rather than pictures of them.

import { createFrame, createFx, composite } from "../../../src/core/index.js";

const SIZE = 40;

/** Draw a spell's effect, once, into a canvas — thumbnailing it by rendering into a small frame. */
export function spellIcon(canvas, mod) {
  const meta = mod.meta ?? {};
  const [w, h] = meta.size ?? [64, 64];
  const [ox, oy] = meta.origin ?? [w / 2, h];
  const frame = createFrame(w, h);
  const img = new Uint8ClampedArray(w * h * 4);
  const inst = createFx(mod, { x: ox, y: oy, ...(meta.options ?? {}) });
  const ctx = canvas.getContext("2d");
  canvas.width = SIZE;
  canvas.height = SIZE;
  ctx.imageSmoothingEnabled = false;

  // find a time in the effect where there's the most to see
  const D = meta.duration ?? 1;
  const best = { score: -1, t: 0 };
  const probes = meta.loop ? [0.15, 0.35, 0.55, 0.75] : [0.12, 0.25, 0.38, 0.5, 0.62];
  for (const p of probes) {
    const tt = D * p;
    inst.update(Math.max(1 / 30, tt - inst.t));
    frame.color.fill(0);
    frame.light.fill(0);
    inst.draw(frame, "front");
    let score = 0;
    for (let i = 0; i < frame.color.length; i++) if (frame.color[i] >>> 24) score++;
    if (score > best.score) best.score = score;
    best.t = tt;
  }
  // redraw at the chosen moment
  const fresh = createFx(mod, { x: ox, y: oy, ...(meta.options ?? {}) });
  if (best.t > 0) fresh.update(best.t);
  frame.color.fill(0);
  frame.light.fill(0);
  fresh.draw(frame, "front");
  composite(frame, img, null);

  // crop to the effect's box, then letterbox it into the icon
  let x0 = w, y0 = h, x1 = -1, y1 = -1;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (img[(y * w + x) * 4 + 3]) {
    if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
  }
  if (x1 < x0 || y1 < y0) { x0 = 0; y0 = 0; x1 = w - 1; y1 = h - 1; }
  const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
  const off = document.createElement("canvas");
  off.width = w;
  off.height = h;
  off.getContext("2d").putImageData(new ImageData(img, w, h), 0, 0);
  const k = Math.min(SIZE / bw, SIZE / bh);
  const dw = bw * k, dh = bh * k;
  ctx.drawImage(off, x0, y0, bw, bh, (SIZE - dw) / 2, (SIZE - dh) / 2, dw, dh);
  return canvas;
}
