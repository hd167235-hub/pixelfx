// The island: a heightfield and a material per tile, generated from a seed. Pure data — no three.js here, so the
// same map runs in the browser and in the offline snapshot tool.
//
// Coordinates: x, z in world units, one unit is one voxel column; y is up. Height is a whole number of voxels,
// so every surface lines up with the voxel grid and reads as chunky blocks on screen.

import { mulberry32, range, fbm, noise2, hash2 } from "./rng.js";

export const N = 128;            // tiles across
export const W = N;              // alias, world width in voxels
export const SEA = 6;            // sea level, in voxels
export const SNOW = 27;          // rock above this line wears snow
export const MAX_H = 46;

/** Tile materials. */
export const M = { DEEP: 0, WATER: 1, SAND: 2, GRASS: 3, DIRT: 4, ROCK: 5, SNOW: 6, PATH: 7, ASH: 8 };

export const MATS = [
  { name: "deep", walk: false },
  { name: "water", walk: false },
  { name: "sand", walk: true },
  { name: "grass", walk: true },
  { name: "dirt", walk: true },
  { name: "rock", walk: true },
  { name: "snow", walk: true },
  { name: "path", walk: true },
  { name: "ash", walk: true },
];

/** Straight-line distance from a point to a segment, in the xz plane. */
export function segDist(px, pz, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az, len = dx * dx + dz * dz;
  let t = len > 0 ? ((px - ax) * dx + (pz - az) * dz) / len : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return Math.hypot(px - (ax + dx * t), pz - (az + dz * t));
}

/**
 * Generate an island. Returns { heights, mats, features, heightAt, matAt }.
 * features: the landmark sites the spells and the scenery care about.
 */
export function makeWorld(seed = 1337) {
  const rnd = mulberry32(seed);
  const h = new Int16Array(N * N);
  const m = new Uint8Array(N * N);
  const idx = (x, z) => z * N + x;

  // ---- shape: a round island with a ragged coast, a mountain ridge, a volcanic cone in the north-east
  const cx = N / 2, cz = N / 2, R = N * 0.44;
  const peak = { x: N * 0.3, z: N * 0.34 };
  const volcano = { x: N * 0.74, z: N * 0.32 };
  const lake = { x: N * 0.72, z: N * 0.72 };
  const ridgeDir = -0.7;

  for (let z = 0; z < N; z++) {
    for (let x = 0; x < N; x++) {
      const dx = (x + 0.5 - cx) / R, dz = (z + 0.5 - cz) / R;
      const d = Math.hypot(dx, dz);
      // ragged coast: the island's radius wobbles with noise
      const coast = fbm(x * 0.035, z * 0.035, seed + 11, 4) - 0.5;
      const shape = 1 - (d + coast * 0.24) ** 2;
      // the land's relief in voxels above the sea line: a dome, a mountain spine, a volcano, rolling detail
      let elev = shape > 0 ? 17 * shape ** 1.5 : 0;
      elev += (fbm(x * 0.09, z * 0.09, seed + 3, 3) - 0.5) * 3.2 * Math.max(0, Math.min(1, shape * 3));
      if (shape > 0.05) {
        const along = (x - peak.x) * Math.cos(ridgeDir) + (z - peak.z) * Math.sin(ridgeDir);
        const across = -(x - peak.x) * Math.sin(ridgeDir) + (z - peak.z) * Math.cos(ridgeDir);
        const ridge = Math.exp(-(across * across) / 240) * Math.exp(-Math.max(0, along) / (N * 0.34));
        const summit = Math.exp(-((x - peak.x) ** 2 + (z - peak.z) ** 2) / 190);
        elev += ridge * 7 + summit * 13;
        // the volcano: a cone with a crater bitten out of the top, ash and slag
        const vd = Math.hypot(x - volcano.x, z - volcano.z);
        const cone = Math.max(0, 1 - vd / 27) ** 1.5;
        const crater = Math.exp(-(vd * vd) / 30);
        elev += cone * 19 - crater * 15;
      }
      // the lake basin, dug under the sea line
      const ld = Math.hypot((x - lake.x) * 0.85, (z - lake.z) * 1.2);
      elev -= Math.max(0, 1 - ld / 15) ** 2 * 12;

      let hh;
      if (elev > 0.5) {
        hh = SEA + Math.round(elev);
        // wide terraces: the lowlands stand in a few big, flat shelves, a whole cliff apart, the way a
        // hand-placed voxel island is built. The edge wanders slowly, and a tile only becomes a step where
        // the ground has been a while rising, so a shelf isn't a staircase of single tiles.
        if (hh <= SEA + 15) {
          const e = elev + fbm(x * 0.07, z * 0.07, seed + 21, 3) * 4.2 - 2.1;
          hh = SEA + Math.max(0, Math.round(e / 4.5)) * 4;
        } else hh = SEA + Math.round((hh - SEA) / 3) * 3;
      } else {
        // under the sea: fall away quickly, so there are beaches and then deep water, not shelves
        hh = SEA + Math.round((elev - 0.5) * 2.4);
      }
      if (hh < 0) hh = 0;
      if (hh > MAX_H) hh = MAX_H;
      h[idx(x, z)] = hh;
    }
  }

  // ---- materials from height, slope and location
  for (let z = 0; z < N; z++) {
    for (let x = 0; x < N; x++) {
      const i = idx(x, z), y = h[i];
      const hx = h[idx(Math.min(N - 1, x + 1), z)], hz = h[idx(x, Math.min(N - 1, z + 1))];
      const slope = Math.max(Math.abs(hx - y), Math.abs(hz - y));
      let mat;
      if (y < SEA - 2) mat = M.DEEP;
      else if (y < SEA) mat = M.WATER;
      else if (y <= SEA + 1) mat = M.SAND;
      else if (y >= SNOW || (y > SNOW - 6 && slope >= 8)) mat = slope >= 8 ? M.ROCK : M.SNOW;
      else if (slope >= 8) mat = M.ROCK;
      else mat = M.GRASS;
      // dry dirt on the south face of the mountain and round the volcano's ash cone
      const vd = Math.hypot(x - volcano.x, z - volcano.z);
      if (y >= SEA + 1 && vd < 15 && y > SEA + 6 && slope < 6) mat = M.ASH;
      m[i] = mat;
    }
  }

  // ---- the road: from the shrine on the west shore to the stone ring in the meadow
  const shrine = { x: 34, z: 96 };
  const ringSite = { x: 80, z: 101 };
  const trail = [];
  {
    let px = shrine.x, pz = shrine.z, heading = -0.35;
    for (let k = 0; k < 90; k++) {
      trail.push([px, pz]);
      heading += (hash2(k, 3, seed) - 0.5) * 0.55;
      // head towards the stone ring now and then, so the road actually arrives
      const want = Math.atan2(ringSite.z - pz, ringSite.x - px);
      const diff = ((want - heading + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      heading += diff * 0.18;
      px += Math.cos(heading);
      pz += Math.sin(heading);
      if (Math.hypot(px - ringSite.x, pz - ringSite.z) < 3) break;
    }
  }
  for (let k = 0; k < trail.length - 1; k++) {
    const [ax, az] = trail[k], [bx, bz] = trail[k + 1];
    for (let x = Math.max(0, Math.min(ax, bx) - 2); x <= Math.min(N - 1, Math.max(ax, bx) + 2); x++)
      for (let z = Math.max(0, Math.min(az, bz) - 2); z <= Math.min(N - 1, Math.max(az, bz) + 2); z++) {
        const i = idx(x, z), y = h[i];
        if (y <= SEA || m[i] === M.WATER || m[i] === M.DEEP) continue;
        const d = segDist(x + 0.5, z + 0.5, ax + 0.5, az + 0.5, bx + 0.5, bz + 0.5);
        if (d < 1.1) m[i] = M.PATH;
        else if (d < 1.7 && (m[i] === M.GRASS || m[i] === M.SNOW)) m[i] = M.DIRT;
      }
  }

  // ---- a flat clearing for the stone ring, so the runes sit on even ground
  const clear = (c, r, target) => {
    for (let z = Math.max(0, c.z - r); z <= Math.min(N - 1, c.z + r); z++)
      for (let x = Math.max(0, c.x - r); x <= Math.min(N - 1, c.x + r); x++) {
        const d = Math.hypot(x - c.x, z - c.z);
        if (d > r) continue;
        const k = d / r, i = idx(x, z);
        h[i] = Math.round(h[i] * (1 - (1 - k) * 0.85) + target * ((1 - k) * 0.85));
        if (m[i] !== M.WATER && m[i] !== M.DEEP && m[i] !== M.PATH) m[i] = Math.hypot(x - c.x, z - c.z) < 2 ? M.DIRT : M.GRASS;
      }
  };
  const ringY = h[idx(ringSite.x, ringSite.z)];
  clear(ringSite, 6, ringY);
  const shrineY = h[idx(shrine.x, shrine.z)];
  clear(shrine, 4, shrineY);
  const camp = { x: 72, z: 94 };
  const campY = h[idx(camp.x, camp.z)];
  clear(camp, 3, campY);
  const spawn = { x: 64, z: 110 };

  // ---- landmarks
  const features = {
    seed,
    spawn: { ...spawn, y: Math.max(h[idx(spawn.x, spawn.z)], SEA) },
    ring: { ...ringSite, y: Math.max(h[idx(ringSite.x, ringSite.z)], SEA), radius: 4.2 },
    shrine: { ...shrine, y: Math.max(h[idx(shrine.x, shrine.z)], SEA) },
    camp: { ...camp, y: Math.max(h[idx(camp.x, camp.z)], SEA) },
    volcano: { x: volcano.x, z: volcano.z, y: h[idx(Math.round(volcano.x), Math.round(volcano.z))] },
    peak: { x: peak.x, z: peak.z, y: h[idx(Math.round(peak.x), Math.round(peak.z))] },
    lake: { x: lake.x, z: lake.z, y: SEA },
    trail,
  };

  // ---- the spawn clearing gets a ring of standing stones to look at, so the first view has something to see
  return { seed, n: N, heights: h, mats: m, features, idx, heightAt: (x, z) => h[idx(clampTile(x), clampTile(z))], matAt: (x, z) => m[idx(clampTile(x), clampTile(z))] };
}

const clampTile = (v) => Math.max(0, Math.min(N - 1, Math.floor(v)));

/** Bilinear height in world units — what the walker and the camera use. */
export function heightAt(world, x, z) {
  const fx = Math.max(0, Math.min(N - 1.001, x)), fz = Math.max(0, Math.min(N - 1.001, z));
  const x0 = Math.floor(fx), z0 = Math.floor(fz), tx = fx - x0, tz = fz - z0;
  const h = world.heights, i = world.idx;
  const a = h[i(x0, z0)], b = h[i(x0 + 1, z0)], c = h[i(x0, z0 + 1)], d = h[i(x0 + 1, z0 + 1)];
  return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz;
}

/** The material under a point. */
export function matAt(world, x, z) {
  return world.mats[world.idx(clampTile(x), clampTile(z))];
}

/** Is (x, z) walkable ground (not water)? */
export function walkable(world, x, z) {
  if (x < 0.5 || z < 0.5 || x > N - 1.5 || z > N - 1.5) return false;
  const m = matAt(world, x, z);
  return MATS[m].walk;
}

export { noise2 };
