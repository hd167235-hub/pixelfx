SPELL WORLD — Đảo Phép Thuật

CÁCH NHANH: mở spell-world.html trong Chrome/Firefox. File này đã gộp game và thư viện.

Nếu trình duyệt Android chặn WebGL khi mở file://, dùng bản thư mục:
- Giải nén spell-world-game.zip.
- Mở terminal trong thư mục spell-world rồi chạy: python -m http.server 8000
- Mở http://localhost:8000/ trên trình duyệt.

Điều khiển: kéo/chạm-kéo để xoay camera; cuộn/pinch để zoom; chạm ô phép để chọn, chạm cảnh để niệm phép; WASD di chuyển; Shift chạy; Space blink; B mở sách; H trợ giúp.
