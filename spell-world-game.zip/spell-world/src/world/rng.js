// Seeded randomness and value noise. Everything in the world is built from a seed, so the same seed always
// gives the same island — and the server-side preview tool (tools/snapshot.mjs) can check the map offline.

/** A small fast PRNG (mulberry32). Returns numbers in [0, 1). */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const range = (rnd, a, b) => a + (b - a) * rnd();
export const pick = (rnd, list) => list[Math.min(list.length - 1, Math.floor(rnd() * list.length))];

/** Integer hash of a lattice point, in [0, 1). */
export function hash2(x, y, seed = 0) {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 362437);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

const smooth = (t) => t * t * (3 - 2 * t);

/** Smooth value noise in [0, 1). */
export function noise2(x, y, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = smooth(x - xi), yf = smooth(y - yi);
  const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
  return a + (b - a) * xf + (c - a) * yf + (a - b - c + d) * xf * yf;
}

/** Fractal value noise in [0, 1), `octaves` layers deep. */
export function fbm(x, y, seed = 0, octaves = 4) {
  let sum = 0, amp = 0.5, norm = 0, f = 1;
  for (let o = 0; o < octaves; o++) {
    sum += noise2(x * f, y * f, seed + o * 131) * amp;
    norm += amp;
    amp *= 0.5;
    f *= 2.03;
  }
  return sum / norm;
}

/** A "worm" — a wandering polyline used to carve paths, rivers and trails. */
export function worm(rnd, x, z, heading, steps, turn = 0.5) {
  const pts = [[x, z]];
  for (let i = 0; i < steps; i++) {
    heading += range(rnd, -turn, turn);
    x += Math.cos(heading);
    z += Math.sin(heading);
    pts.push([x, z]);
  }
  return pts;
}
