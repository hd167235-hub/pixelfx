// Đảo Phép Thuật — boot the world, wire the input, run the frame loop.

import * as THREE from "three";
import { SpellWorld } from "./game/world.js";
import { SPELLBOOK, SPELL_LIST, SCHOOLS } from "./spells/catalog.js";
import { spellIcon } from "./ui/icons.js";
import { Sound } from "./ui/sound.js";
import { walkable } from "./world/terrain.js";

const $ = (s) => document.querySelector(s);
const params = new URLSearchParams(location.search);
const seed = Number(params.get("seed") ?? 1337) || 1337;

const canvas = $("#view");
const bootBar = $("#boot-bar");
const bootNote = $("#boot-note");

const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));
async function boot() {
  const steps = [
    ["raising the island", 0.15],
    ["growing the pines", 0.3],
    ["filling the sea", 0.5],
    ["waking the wizard", 0.72],
    ["lighting the stones", 0.9],
  ];
  for (const [text, p] of steps) {
    bootNote.textContent = text + "…";
    bootBar.style.width = `${p * 100}%`;
    await nextFrame();
    await nextFrame();
  }
  const world = new SpellWorld(canvas, seed);
  window.spellWorld = world; // for the console, and for curious people
  bootBar.style.width = "100%";
  bootNote.textContent = "ready";
  await nextFrame();
  $("#boot").classList.add("gone");
  $("#boot").hidden = true;
  return world;
}

let world;
try {
  world = await boot();
} catch (err) {
  console.error(err);
  bootNote.textContent = "Lỗi khởi động: " + (err?.message ?? err);
  bootNote.style.color = "#ff9a9a";
  throw err;
}
// a visible diagnostics box: errors (three.js reports shader problems through console.error) and renderer
// stats show up on screen, so a black canvas can be diagnosed from a screenshot
const errBox = document.createElement("div");
errBox.style.cssText = "position:fixed;left:8px;top:8px;z-index:9999;max-width:92vw;background:rgba(20,20,40,.92);color:#ffd7d7;font:11px/1.5 monospace;padding:8px 10px;border-radius:6px;display:none;white-space:pre-wrap;cursor:pointer;";
errBox.addEventListener("pointerdown", () => { errBox.style.display = "none"; diagLines.length = 0; });
document.body.appendChild(errBox);
const diagLines = [];
const showErr = (m) => {
  diagLines.push(String(m));
  if (diagLines.length > 8) diagLines.shift();
  errBox.style.display = "block";
  errBox.textContent = diagLines.join("\n");
};
window.addEventListener("error", (e) => showErr("ERR " + (e.message ?? "unknown")));
window.addEventListener("unhandledrejection", (e) => showErr("REJ " + (e.reason?.message ?? e.reason)));
const origConsoleError = console.error.bind(console);
console.error = (...a) => { showErr(a.map((x) => (x && x.message) || String(x)).join(" ")); origConsoleError(...a); };
const sound = new Sound();
const state = {
  selected: SPELLBOOK[params.get("spell")] ? params.get("spell") : "fireball",
  pointer: new THREE.Vector2(0, -0.25),
  dragging: false,
  lastX: 0,
  lastY: 0,
  dragDist: 0,
  lastCast: -1,
  open: true,
};

// ---------------------------------------------------------------- casting
function castAtPointer() {
  const aim = world.aimPoint(state.pointer.x, state.pointer.y);
  doCast(state.selected, aim);
}
function doCast(id, aim) {
  const spell = SPELLBOOK[id];
  if (!spell || !state.open) return;
  const before = world.stats.casts;
  world.cast(id, aim);
  if (world.stats.casts !== before) {
    sound.cast(spell);
    if (spell.shake) world.camShake = Math.max(world.camShake ?? 0, spell.shake * 0.5);
    if (spell.school === "lightning" || spell.school === "holy") {
      document.body.animate([{ filter: "brightness(1.3)" }, { filter: "brightness(1)" }], { duration: 160, easing: "ease-out" });
    }
  }
}
function blink() {
  if (!state.open) return;
  const aim = world.aimPoint(state.pointer.x, state.pointer.y);
  const p = world.wizard.pos;
  const dir = new THREE.Vector2(aim.x - p.x, aim.z - p.z);
  const len = Math.min(9, dir.length());
  if (len < 0.6) return;
  dir.normalize();
  const nx = p.x + dir.x * len, nz = p.z + dir.y * len;
  if (!walkable(world.world, nx, nz)) return;
  world.fx.spawn(SPELLBOOK.poof.mod, p.clone(), { scale: 0.05 });
  world.wizard.teleportTo(nx, nz);
  world.fx.spawn(SPELLBOOK.warpIn.mod, world.wizard.pos.clone().setY(world.wizard.pos.y + 0.1), { scale: 0.05, glow: 1.5 });
  sound.blink();
}

// ---------------------------------------------------------------- input
const keys = new Set();
addEventListener("keydown", (e) => {
  if (e.repeat) return;
  keys.add(e.code);
  const combo = (e.shiftKey ? "Shift+" : "") + (e.code.startsWith("Digit") ? e.code.slice(5) : e.key.length === 1 ? e.key.toUpperCase() : e.key);
  const found = SPELL_LIST.find((s) => s.key.toUpperCase() === combo.toUpperCase());
  if (found) {
    select(found.id);
    castAtPointer();
    e.preventDefault();
    return;
  }
  switch (e.code) {
    case "Space": blink(); e.preventDefault(); break;
    case "KeyH": toggleSheet(); break;
    case "KeyM": sound.toggle(); break;
    case "Escape": toggleSheet(false); break;
  }
});
addEventListener("keyup", (e) => keys.delete(e.code));
addEventListener("blur", () => keys.clear());

canvas.addEventListener("pointerdown", (e) => {
  state.dragging = true;
  state.lastX = e.clientX;
  state.lastY = e.clientY;
  state.dragDist = 0;
  canvas.setPointerCapture?.(e.pointerId);
});
canvas.addEventListener("pointermove", (e) => {
  const r = canvas.getBoundingClientRect();
  state.pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1));
  if (!state.dragging) return;
  const dx = e.clientX - state.lastX, dy = e.clientY - state.lastY;
  state.dragDist += Math.abs(dx) + Math.abs(dy);
  world.rotate(-dx * 0.006, dy * 0.004);
  state.lastX = e.clientX;
  state.lastY = e.clientY;
});
canvas.addEventListener("pointerup", (e) => {
  state.dragging = false;
  if (state.dragDist < 6 && e.button === 0) castAtPointer();
  canvas.releasePointerCapture?.(e.pointerId);
});
canvas.addEventListener("wheel", (e) => {
  world.zoom(Math.sign(e.deltaY) * 1.6);
  e.preventDefault();
}, { passive: false });
canvas.addEventListener("contextmenu", (e) => e.preventDefault());

// ---------------------------------------------------------------- HUD
const slots = new Map();
const QUICK = [
  ["fireball", "1"], ["iceCrystal", "2"], ["lightning", "3"], ["heal", "4"], ["blessing", "5"], ["arcaneOrb", "6"],
  ["smite", "Q"], ["holyPillar", "W"], ["portal", "E"], ["missiles", "R"], ["starFall", "T"],
  ["blackHole", "A"], ["tendrils", "S"], ["soulDrain", "D"], ["bloom", "F"], ["leafStorm", "G"], ["vines", "H"],
  ["teleporter", "Z"], ["warpIn", "X"], ["poof", "C"],
];
function buildSpellbar() {
  const bar = $("#spellbar");
  bar.innerHTML = "";
  for (const [id, key] of QUICK) {
    const spell = SPELLBOOK[id];
    if (!spell) continue;
    const el = document.createElement("div");
    el.className = "slot";
    el.title = `${spell.name} — ${spell.desc} (${spell.cost} mana)`;
    el.append(spellIcon(document.createElement("canvas"), spell.mod));
    const k = document.createElement("div");
    k.className = "k";
    k.textContent = key;
    el.append(k);
    const cost = document.createElement("div");
    cost.className = "cost";
    cost.textContent = spell.cost;
    el.append(cost);
    el.addEventListener("click", () => { select(id); castAtPointer(); });
    bar.append(el);
    slots.set(id, el);
  }
}
function select(id) {
  if (!SPELLBOOK[id]) return;
  state.selected = id;
  const spell = SPELLBOOK[id];
  for (const [sid, el] of slots) el.classList.toggle("on", sid === id);
  $("#school").textContent = SCHOOLS[spell.school]?.name ?? spell.school;
  $("#school").style.color = spell.light;
  world.wizard.setStaffColor(spell.light);
  sound.select();
}
buildSpellbar();
select(state.selected);

function buildBook() {
  const book = $("#book");
  book.innerHTML = "";
  for (const s of SPELL_LIST) {
    const item = document.createElement("div");
    item.className = "book-item";
    item.style.setProperty("--c", s.light);
    item.append(spellIcon(document.createElement("canvas"), s.mod));
    const t = document.createElement("div");
    t.innerHTML = `<b>${s.name}</b><small>${s.key} · ${s.cost} mana</small>`;
    item.append(t);
    item.title = s.desc;
    item.addEventListener("click", () => { select(s.id); toggleSheet(false); });
    book.append(item);
  }
}
buildBook();

function toggleSheet(force) {
  const sheet = $("#sheet");
  const show = force ?? sheet.hidden;
  sheet.hidden = !show;
  state.open = !show;
}
$("#btn-help").addEventListener("click", () => toggleSheet(true));
$("#btn-go").addEventListener("click", () => toggleSheet(false));
$("#btn-sound").addEventListener("click", () => sound.toggle());

let noticeTimer = 0;
world.on("notice", (text, kind) => {
  const n = $("#notice");
  n.textContent = text;
  n.className = `notice show ${kind ?? ""}`;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => (n.className = "notice"), 1800);
});
world.on("quest", () => {
  $("#quest-text").textContent = "You found the gate. The stones are lit — the island is yours to wander.";
  $("#quest-dist").textContent = "✦ quest complete";
  sound.chime();
  const n = $("#notice");
  n.textContent = "✦ The gate answers your staff ✦";
  n.className = "notice show";
  setTimeout(() => (n.className = "notice"), 3200);
});

// ---------------------------------------------------------------- loop
const DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
const move = { x: 0, z: 0 };
let last = performance.now();
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;

  // movement, turned by the camera
  const fwd = world.forward(), right = world.right();
  move.x = 0; move.z = 0;
  const held = (c) => keys.has(c);
  if (held("KeyW") || held("ArrowUp")) { move.x += fwd.x; move.z += fwd.y; }
  if (held("KeyS") || held("ArrowDown")) { move.x -= fwd.x; move.z -= fwd.y; }
  if (held("KeyD") || held("ArrowRight")) { move.x += right.x; move.z += right.y; }
  if (held("KeyA") || held("ArrowLeft")) { move.x -= right.x; move.z -= right.y; }
  if (held("KeyQ")) world.rotate(-1.6 * dt, 0);
  if (held("KeyE")) world.rotate(1.6 * dt, 0);
  const sprint = held("ShiftLeft") || held("ShiftRight");

  try {
    world.update(dt, { move, sprint });
  } catch (err) {
    console.error(err);
    showErr(err.message ?? err);
  }
  if (!frame.diagDone) {
    frame.diagDone = true;
    const info = world.renderer.info;
    const v3 = (v) => v.toArray().map((n) => n.toFixed(1)).join(",");
    showErr(`cam ${v3(world.camera.position)} wiz ${v3(world.wizard.pos)} calls ${info.render.calls} tris ${info.render.triangles} progs ${info.programs.length}`);
  }

  // HUD
  const w = world.wizard;
  $("#hp-fill").style.width = `${(w.hp / w.maxHp) * 100}%`;
  $("#mana-fill").style.width = `${(w.mana / w.maxMana) * 100}%`;
  $("#stam-fill").style.width = `${Math.round(w.stamina)}%`;
  $("#hp-text").textContent = Math.round(w.hp);
  $("#mana-text").textContent = Math.round(w.mana);
  for (const [id, el] of slots) {
    const s = SPELLBOOK[id], cd = world.cooldowns[id] ?? 0;
    el.style.setProperty("--cd", (cd / Math.max(0.01, s.cooldown)).toFixed(2));
    el.classList.toggle("off", w.mana < s.cost);
  }
  // where north is, on screen
  const i = Math.round(((-world.orbit.yaw / (Math.PI * 2)) * 8 + 8)) % 8;
  $("#compass").textContent = DIRS[i];
  if (!world.quest.done && world.quest.distance !== undefined) $("#quest-dist").textContent = `${Math.round(world.quest.distance)} m to the gate`;

  sound.setAmbience(w);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

addEventListener("resize", () => world.resize());

// the card greets you once; ?nointro skips it
if (!params.has("nointro")) toggleSheet(true);
