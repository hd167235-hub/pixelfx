// How a world made of tiles becomes a picture.
//
// The island is a heightfield. Instead of meshing it into cubes, every tile stands up as ONE flat billboard
// (a quad) from the tile's floor to its top, and every tile also lays a flat quad on top of itself, at its
// height. The billboards all face the camera, so together they read as a solid column of land seen from a
// low, raking angle — the "2.5D diorama" look — while staying cheap enough to draw a whole island at 60 fps.
// Top faces are depth-tested against the billboards, so nearer ground hides the ground behind it.
//
// This module is deliberately free of three.js: makeColumns() returns plain typed arrays, so the offline
// snapshot tool can project them in Node and check what the camera is actually looking at.

import { N, SEA, M } from "./terrain.js";

/** Colour helper: hex string to [r, g, b] in 0..1. */
function rgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

/** The palette of the island. Not three.js colours: plain arrays, converted where they are used. */
export const C = {
  skyTop: rgb("#0a0d24"),
  skyMid: rgb("#3a2a63"),
  skyLow: rgb("#a2506b"),
  skyGlow: rgb("#ffb16b"),
  sun: rgb("#ffd9a0"),
  stars: rgb("#e8e4ff"),
  fog: rgb("#4a3555"),
  water: ["#0b1a33", "#123059", "#1a4a80", "#2370a8", "#3f9ac0", "#7fd0d0"].map(rgb),
  sand: ["#6e5539", "#8f6f48", "#ad8a5c", "#c8a475", "#dcc191"].map(rgb),
  grass: ["#1c3a2a", "#24482e", "#2d5836", "#37693e", "#437a46", "#528c4f"].map(rgb),
  dirt: ["#2a1f18", "#3a2a1d", "#4c3826", "#61482e"].map(rgb),
  rock: ["#2b2836", "#3b3748", "#4e485c", "#635c72", "#7d7588"].map(rgb),
  snow: ["#8fa6c8", "#b8cbe4", "#dce9f7", "#ffffff"].map(rgb),
  path: ["#4a3a2a", "#62503a", "#7d6647", "#9a8058"].map(rgb),
  ash: ["#1d171c", "#2b232a", "#3a2f36", "#4b3c40"].map(rgb),
  glow: rgb("#7ff6ff"),
  ember: rgb("#ff7a3c"),
};

/** The palette for a material, low to high. */
export function rampOf(mat, h) {
  switch (mat) {
    case M.WATER: return C.water;
    case M.DEEP: return C.water;
    case M.SAND: return C.sand;
    case M.GRASS: return C.grass;
    case M.DIRT: return C.dirt;
    case M.ROCK: return C.rock;
    case M.SNOW: return C.snow;
    case M.PATH: return C.path;
    case M.ASH: return C.ash;
    default: return C.grass;
  }
}

/**
 * Turn a world into the columns the renderer draws.
 *
 * For every tile: its height, its material, and — for the flat top face — the material and height of the
 * four tiles around it, so the shader can put a lip of cliff on the edge of a raised block, and beach sand
 * on the skirt of an island.
 *
 * height = max(tile height, sea level) so the water surface is a flat plane at SEA.
 */
export function makeColumns(world) {
  const n = N, total = n * n;
  const out = {
    n,
    total,
    top: new Float32Array(total),      // the height of the column's top face
    bottom: new Float32Array(total),   // the lowest ground beside it: the cliff face spans bottom..top
    ground: new Float32Array(total),   // the real ground height (dry land can be below sea level on the coast)
    mat: new Uint8Array(total),
    matN: new Uint8Array(total), matS: new Uint8Array(total), matE: new Uint8Array(total), matW: new Uint8Array(total),
    hN: new Float32Array(total), hS: new Float32Array(total), hE: new Float32Array(total), hW: new Float32Array(total),
    shore: new Float32Array(total),    // 0 dry, 1 underwater — how much sand to tint the skirt
    jitter: new Float32Array(total),   // a little per-tile variation, so blocks don't look extruded
  };
  const H = world.heights, Mt = world.mats, idx = world.idx;
  const at = (x, z) => (x < 0 || z < 0 || x >= n || z >= n ? null : idx(x, z));
  for (let z = 0; z < n; z++) {
    for (let x = 0; x < n; x++) {
      const i = idx(x, z);
      const g = H[i];
      const top = Math.max(g, SEA);
      out.top[i] = top;
      out.ground[i] = g;
      out.mat[i] = Mt[i];
      const nb = [at(x, z - 1), at(x + 1, z), at(x, z + 1), at(x - 1, z)];
      const arrs = [out.hN, out.hE, out.hS, out.hW], mats = [out.matN, out.matE, out.matS, out.matW];
      for (let k = 0; k < 4; k++) {
        const j = nb[k];
        arrs[k][i] = j == null ? 0 : Math.max(H[j], SEA);
        mats[k][i] = j == null ? M.DEEP : Mt[j];
      }
      // the cliff face only has to cover the drop to the lowest neighbour: above that, the top faces
      // of the surrounding tiles already hide what's behind
      let bot = Infinity;
      for (let k = 0; k < 4; k++) bot = Math.min(bot, arrs[k][i]);
      out.bottom[i] = nb.some((j) => j == null || H[j] < SEA - 1) ? Math.min(bot, SEA) : bot;
      if (out.bottom[i] > top - 0.5) out.bottom[i] = top;   // flat ground needs no cliff face at all
      // under the water there is no cliff to draw
      if (Mt[i] === M.WATER || Mt[i] === M.DEEP) out.bottom[i] = out.top[i];
      out.shore[i] = g < SEA ? 1 : 0;
      out.jitter[i] = (Math.sin(x * 12.9898 + z * 78.233) * 43758.5453) % 1;
    }
  }
  return out;
}

/** A cheap deterministic hash in [-1, 1) for decoration placement. */
export function tileRand(x, z, k = 0) {
  const s = Math.sin(x * 127.1 + z * 311.7 + k * 74.7) * 43758.5453;
  return (s - Math.floor(s)) * 2 - 1;
}
