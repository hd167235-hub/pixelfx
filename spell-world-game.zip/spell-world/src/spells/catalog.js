// The spellbook. Each spell is a recipe over the pixelfx library plus the way it behaves in the world:
// where the player is, what it costs, where its effect should appear, how it moves, when to cast (the keys).

import * as fireballMod from "../../../src/fx/fire/fireball.js";
import * as fireRingMod from "../../../src/fx/fire/fire-ring.js";
import * as fireTornadoMod from "../../../src/fx/fire/fire-tornado.js";
import * as flamePillarMod from "../../../src/fx/fire/flame-pillar.js";
import * as meteorMod from "../../../src/fx/fire/meteor.js";
import * as iceCrystalMod from "../../../src/fx/ice/ice-crystal.js";
import * as arcaneOrbMod from "../../../src/fx/arcane/arcane-orb.js";
import * as frostNovaMod from "../../../src/fx/ice/frost-nova.js";
import * as iceSpikesMod from "../../../src/fx/ice/ice-spikes.js";
import * as blizzardMod from "../../../src/fx/ice/blizzard-vortex.js";
import * as lightningMod from "../../../src/fx/lightning/lightning-strike.js";
import * as chainMod from "../../../src/fx/lightning/chain-lightning.js";
import * as ballMod from "../../../src/fx/lightning/ball-lightning.js";
import * as stormMod from "../../../src/fx/lightning/storm-cloud.js";
import * as healMod from "../../../src/fx/holy/heal-aoe.js";
import * as divineMod from "../../../src/fx/holy/divine-shield.js";
import * as smiteMod from "../../../src/fx/holy/smite.js";
import * as holyPillarMod from "../../../src/fx/holy/holy-pillar.js";
import * as blessMod from "../../../src/fx/holy/blessing.js";
import * as portalMod from "../../../src/fx/arcane/portal.js";
import * as missilesMod from "../../../src/fx/arcane/arcane-missiles.js";
import * as runeCircleMod from "../../../src/fx/arcane/rune-circle.js";
import * as starFallMod from "../../../src/fx/arcane/star-fall.js";
import * as magicCircleMod from "../../../src/fx/arcane/magic-circle-cast.js";
import * as blackHoleMod from "../../../src/fx/shadow/black-hole.js";
import * as tendrilsMod from "../../../src/fx/shadow/shadow-tendrils.js";
import * as soulDrainMod from "../../../src/fx/shadow/soul-drain.js";
import * as bloomMod from "../../../src/fx/nature/healing-bloom.js";
import * as leafStormMod from "../../../src/fx/nature/leaf-storm.js";
import * as vinesMod from "../../../src/fx/nature/vine-whip.js";
import * as teleportPadMod from "../../../src/fx/scifi/teleporter-pad.js";
import * as warpInMod from "../../../src/fx/scifi/warp-in.js";
import * as poofMod from "../../../src/fx/spawn/poof.js";

export const SPELLBOOK = {
  fireball: {
    id: "fireball", name: "Fireball", school: "fire", key: "1", cost: 8, cooldown: 0.22,
    desc: "A ball of flame thrown forward. It flies, and where it lands it burns.",
    mod: fireballMod, scale: 0.05, 
    castAt: "hand", light: "#ff8a3c",
    cat: ["fire/fireball"], travel: { speed: 17, range: 30, arc: 0.35 },
  },
  meteor: {
    id: "meteor", name: "Meteor", school: "fire", key: "Shift+1", cost: 26, cooldown: 1.2,
    desc: "Call a burning rock out of the sky. Slow to land, enormous when it does.",
    mod: meteorMod, scale: 0.055, target: { radius: 2.6, range: 26 },
    castAt: "sky", light: "#ff7a3c", shake: 0.8,
    cat: ["fire/meteor"],
  },
  flamePillar: {
    id: "flamePillar", name: "Flame pillar", school: "fire", key: "Shift+2", cost: 14, cooldown: 0.7,
    desc: "A column of fire erupts under the caster's staff.",
    mod: flamePillarMod, scale: 0.05, target: { radius: 2.2, range: 8 },
    castAt: "ground", light: "#ff9a4a",
    cat: ["fire/flame-pillar"],
  },
  fireRing: {
    id: "fireRing", name: "Fire ring", school: "fire", key: "Shift+3", cost: 22, cooldown: 1.8,
    desc: "A ring of fire rolls out around you and everything in it burns.",
    mod: fireRingMod, scale: 0.05, castAt: "ground", light: "#ff8a3c",
    cat: ["fire/fire-ring"],
  },
  iceCrystal: {
    id: "iceCrystal", name: "Ice crystal", school: "ice", key: "2", cost: 10, cooldown: 0.5,
    desc: "A floating shard of ice, humming, that chills the air around it.",
    mod: iceCrystalMod, scale: 0.05, travel: { speed: 10, range: 22, arc: 0.08 },
    castAt: "hand", light: "#8fdcff",
    cat: ["ice/ice-crystal"],
  },
  frostNova: {
    id: "frostNova", name: "Frost nova", school: "ice", key: "Shift+4", cost: 24, cooldown: 1.2,
    desc: "Three rings of ice bloom out from the caster and freeze the ground.",
    mod: frostNovaMod, scale: 0.045, castAt: "ground", light: "#a6ecff",
    cat: ["ice/frost-nova"],
  },
  iceSpikes: {
    id: "iceSpikes", name: "Ice spikes", school: "ice", key: "Shift+5", cost: 16, cooldown: 0.9,
    desc: "Spikes of ice burst up in a line in front of you.",
    mod: iceSpikesMod, scale: 0.05, target: { radius: 2.4, range: 18, line: true },
    castAt: "ground", light: "#9be4ff",
    cat: ["ice/ice-spikes"],
  },
  blizzard: {
    id: "blizzard", name: "Blizzard vortex", school: "ice", key: "Shift+6", cost: 30, cooldown: 1.6,
    desc: "A spinning column of snow and hail that drags everything in.",
    mod: blizzardMod, scale: 0.05, target: { radius: 3.2, range: 22 },
    castAt: "ground", light: "#bfeaff",
    cat: ["ice/blizzard-vortex"],
  },
  lightning: {
    id: "lightning", name: "Lightning strike", school: "lightning", key: "3", cost: 18, cooldown: 0.8,
    desc: "A bolt from a clear sky, aimed where you point.",
    mod: lightningMod, scale: 0.045, target: { radius: 2.4, range: 30 },
    castAt: "sky", light: "#8fc8ff", shake: 0.5,
    cat: ["lightning/lightning-strike"],
  },
  chain: {
    id: "chain", name: "Chain lightning", school: "lightning", key: "Shift+7", cost: 20, cooldown: 1.2,
    desc: "A bolt that leaps from the staff through everything nearby.",
    mod: chainMod, scale: 0.045, target: { radius: 3.4, range: 12 },
    castAt: "hand", light: "#a0d8ff",
    cat: ["lightning/chain-lightning"],
  },
  stormCloud: {
    id: "stormCloud", name: "Storm cloud", school: "lightning", key: "Shift+8", cost: 28, cooldown: 1.6,
    desc: "A cloud gathers overhead and rains thunder on a spot.",
    mod: stormMod, scale: 0.05, target: { radius: 3.0, range: 26 },
    castAt: "sky", light: "#9fc4ff", shake: 0.6,
    cat: ["lightning/storm-cloud"],
  },
  heal: {
    id: "heal", name: "Healing ring", school: "holy", key: "4", cost: 18, cooldown: 0.9,
    desc: "A ring of green light rolls out from your feet and mends what it touches.",
    mod: healMod, scale: 0.05, castAt: "ground", light: "#7ee88a", heal: 40,
    cat: ["holy/heal-aoe"],
  },
  blessing: {
    id: "blessing", name: "Blessing", school: "holy", key: "5", cost: 12, cooldown: 1.0,
    desc: "Warm golden light settles over the wizard and steadies him.",
    mod: blessMod, scale: 0.05, castAt: "self", light: "#ffe066", heal: 18,
    cat: ["holy/blessing"],
  },
  divineShield: {
    id: "divineShield", name: "Divine shield", school: "holy", key: "Shift+9", cost: 20, cooldown: 1.4,
    desc: "A bubble of gold light: nothing gets through while it holds.",
    mod: divineMod, scale: 0.05, castAt: "self", light: "#ffd84a", shield: 3.5,
    cat: ["holy/divine-shield"],
  },
  smite: {
    id: "smite", name: "Smite", school: "holy", key: "Q", cost: 24, cooldown: 1.6,
    desc: "A hammer of daylight drops where you aim.",
    mod: smiteMod, scale: 0.05, target: { radius: 2.6, range: 26 },
    castAt: "sky", light: "#fff0a0", shake: 0.7,
    cat: ["holy/smite"],
  },
  holyPillar: {
    id: "holyPillar", name: "Holy pillar", school: "holy", key: "W", cost: 26, cooldown: 2.0,
    desc: "A shaft of light opens on the ground and stays lit a while.",
    mod: holyPillarMod, scale: 0.05, target: { radius: 2.2, range: 20 },
    castAt: "sky", light: "#ffe680", hold: 1.2,
    cat: ["holy/holy-pillar"],
  },
  portal: {
    id: "portal", name: "Portal", school: "arcane", key: "E", cost: 30, cooldown: 0.25,
    desc: "Tear a rift in the air. Cast it again to step through it.",
    mod: portalMod, scale: 0.05, castAt: "ahead", light: "#c684ff", portal: true,
    cat: ["arcane/portal"],
  },
  arcaneOrb: {
    id: "arcaneOrb", name: "Arcane orb", school: "arcane", key: "6", cost: 12, cooldown: 0.6,
    desc: "A slow orb of violet glass that drifts where you send it.",
    mod: arcaneOrbMod, scale: 0.05, travel: { speed: 8, range: 24, arc: 0.12 },
    castAt: "hand", light: "#c684ff",
    cat: ["arcane/arcane-orb"],
  },
  missiles: {
    id: "missiles", name: "Arcane missiles", school: "arcane", key: "R", cost: 16, cooldown: 1.1,
    desc: "Three purple missiles curve away from the staff.",
    mod: missilesMod, scale: 0.05, castAt: "hand", light: "#ecc8ff",
    cat: ["arcane/arcane-missiles"],
  },
  starFall: {
    id: "starFall", name: "Star fall", school: "arcane", key: "T", cost: 32, cooldown: 1.6,
    desc: "Stars rain down on a wide area, each landing with a flash.",
    mod: starFallMod, scale: 0.05, target: { radius: 3.4, range: 26 },
    castAt: "sky", light: "#ecc8ff", shake: 0.5,
    cat: ["arcane/star-fall"],
  },
  runeCircle: {
    id: "runeCircle", name: "Rune circle", school: "arcane", key: "Shift+0", cost: 10, cooldown: 0.9,
    desc: "Draw a rune circle on the ground. It turns, it glows, it marks the spot.",
    mod: runeCircleMod, scale: 0.05, target: { radius: 1.2, range: 22 },
    castAt: "ground", light: "#ecc8ff", hold: 2.0,
    cat: ["arcane/rune-circle"],
  },
  blackHole: {
    id: "blackHole", name: "Black hole", school: "shadow", key: "A", cost: 34, cooldown: 2.0,
    desc: "Open a hole in the world. Everything near it is pulled to the dark.",
    mod: blackHoleMod, scale: 0.05, target: { radius: 3.2, range: 24 },
    castAt: "air", light: "#8a5cff", hold: 2.6,
    cat: ["shadow/black-hole"],
  },
  tendrils: {
    id: "tendrils", name: "Shadow tendrils", school: "shadow", key: "S", cost: 18, cooldown: 1.2,
    desc: "Black vines whip out of the earth and grab at what's close.",
    mod: tendrilsMod, scale: 0.05, target: { radius: 2.8, range: 14 },
    castAt: "ground", light: "#a970e0",
    cat: ["shadow/shadow-tendrils"],
  },
  soulDrain: {
    id: "soulDrain", name: "Soul drain", school: "shadow", key: "D", cost: 22, cooldown: 1.2,
    desc: "A tether to the nearest creature: drains it and pours the life into you.",
    mod: soulDrainMod, scale: 0.05, castAt: "self", light: "#b07ce0",
    cat: ["shadow/soul-drain"],
  },
  bloom: {
    id: "bloom", name: "Healing bloom", school: "nature", key: "F", cost: 16, cooldown: 1.0,
    desc: "A sprout unfurls into a flower of light where you point.",
    mod: bloomMod, scale: 0.05, target: { radius: 1.6, range: 22 },
    castAt: "ground", light: "#a0e46c", heal: 22,
    cat: ["nature/healing-bloom"],
  },
  leafStorm: {
    id: "leafStorm", name: "Leaf storm", school: "nature", key: "G", cost: 15, cooldown: 1.0,
    desc: "A whirl of leaves and green wind.",
    mod: leafStormMod, scale: 0.05, target: { radius: 2.8, range: 20 },
    castAt: "ground", light: "#b4e070",
    cat: ["nature/leaf-storm"],
  },
  vines: {
    id: "vines", name: "Vine whip", school: "nature", key: "H", cost: 12, cooldown: 0.8,
    desc: "A thorned vine snaps out from your hand.",
    mod: vinesMod, scale: 0.05, target: { radius: 2.4, range: 12, line: true },
    castAt: "hand", light: "#86c84e",
    cat: ["nature/vine-whip"],
  },
  teleporter: {
    id: "teleporter", name: "Teleport pad", school: "arcane", key: "Z", cost: 18, cooldown: 0.6,
    desc: "A ring of light marks this spot. Step between it and your staff.",
    mod: teleportPadMod, scale: 0.05, castAt: "ground", light: "#4ce8d8", hold: 1.5,
    cat: ["scifi/teleporter-pad"],
  },
  warpIn: {
    id: "warpIn", name: "Warp in", school: "arcane", key: "X", cost: 14, cooldown: 0.8,
    desc: "Blink a short way towards where you're looking.",
    mod: warpInMod, scale: 0.05, castAt: "self", light: "#b4fff0", blink: 9,
    cat: ["scifi/warp-in"],
  },
  poof: {
    id: "poof", name: "Poof", school: "arcane", key: "C", cost: 4, cooldown: 0.2,
    desc: "A small puff of smoke. Why not?",
    mod: poofMod, scale: 0.05, castAt: "ground", light: "#a4a4b2",
    cat: ["spawn/poof"],
  },
};

export const SPELL_LIST = Object.values(SPELLBOOK);
export const SCHOOLS = {
  fire: { name: "Fire", color: "#ff8a3c", spells: ["fireball", "meteor", "flamePillar", "fireRing"] },
  ice: { name: "Ice", color: "#8fdcff", spells: ["iceCrystal", "frostNova", "iceSpikes", "blizzard"] },
  lightning: { name: "Lightning", color: "#a0d8ff", spells: ["lightning", "chain", "stormCloud"] },
  holy: { name: "Holy", color: "#ffe066", spells: ["heal", "blessing", "divineShield", "smite", "holyPillar"] },
  arcane: { name: "Arcane", color: "#c684ff", spells: ["portal", "arcaneOrb", "missiles", "starFall", "runeCircle", "teleporter", "warpIn", "poof"] },
  shadow: { name: "Shadow", color: "#a970e0", spells: ["blackHole", "tendrils", "soulDrain"] },
  nature: { name: "Nature", color: "#b4e070", spells: ["bloom", "leafStorm", "vines"] },
};
