// The player: a wizard who walks the island, points his staff, and casts.
//
// The body is pixelfx's rig drawn into a canvas and carried on a camera-facing plane, so he's a proper little
// 3D-standing sprite — you can orbit him and he keeps facing you, the way a pixel game would. His staff is a
// real object in the world, and the tip of it is where spells come from.

import * as THREE from "three";
import { magePixels } from "./mage.js";
import { heightAt, matAt, walkable } from "../world/terrain.js";

const POSE_FPS = 10;
const WALK_SPEED = 6.2;
const SPRITE_W = 96, SPRITE_H = 96, ORIGIN_X = 48, ORIGIN_Y = 80;

function pixelsToTexture(px) {
  const c = document.createElement("canvas");
  c.width = px.w;
  c.height = px.h;
  const ctx = c.getContext("2d");
  ctx.putImageData(new ImageData(px.rgba, px.w, px.h), 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class Wizard {
  constructor(scene, world, spawn) {
    this.world = world;
    this.scene = scene;
    this.pos = new THREE.Vector3(spawn.x, heightAt(world, spawn.x, spawn.z), spawn.z);
    this.facing = -Math.PI / 2;       // towards the sunset, i.e. north (-z), at the start
    this.vel = new THREE.Vector3();
    this.speed = 0;
    this.poseName = "stand";
    this.poseClock = 0;
    this.walkClock = 0;
    this.hp = 100; this.maxHp = 100;
    this.mana = 100; this.maxMana = 100;
    this.stamina = 100;
    this.shield = 0;
    this.castLock = 0;               // seconds left of the cast animation
    this.hurtFlash = 0;

    // the body: a camera-facing plane
    this.textures = {};
    for (const name of ["stand", "walk1", "walk2", "gather", "push", "hold", "hurt", "dash", "sit"]) this.textures[name] = pixelsToTexture(magePixels(name));
    const scale = 0.055;            // world units per art pixel: he stands about 2 units tall, a little under one cliff
    this.spriteScale = scale;
    const geo = new THREE.PlaneGeometry(SPRITE_W * scale, SPRITE_H * scale);
    geo.translate((SPRITE_W / 2 - ORIGIN_X) * scale, (SPRITE_H / 2 - (SPRITE_H - ORIGIN_Y)) * scale, 0);
    this.mat = new THREE.MeshBasicMaterial({ map: this.textures.stand, transparent: true, alphaTest: 0.4, depthWrite: true, side: THREE.DoubleSide, toneMapped: false });
    this.sprite = new THREE.Mesh(geo, this.mat);
    this.sprite.renderOrder = 10;
    this.group = new THREE.Group();
    this.group.add(this.sprite);
    scene.add(this.group);

    // the staff: a tall thin rod with a glowing stone, held in the near hand
    const staff = new THREE.Group();
    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.06, 2.5, 5),
      new THREE.MeshBasicMaterial({ color: 0x4a341e, toneMapped: false }),
    );
    shaft.position.y = 1.05;
    staff.add(shaft);
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.08, 0.16, 6), new THREE.MeshBasicMaterial({ color: 0x8a6a3a, toneMapped: false }));
    collar.position.y = 2.24;
    staff.add(collar);
    const gemMat = new THREE.MeshBasicMaterial({ color: 0xc684ff, toneMapped: false });
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.19, 0), gemMat);
    gem.position.y = 2.46;
    staff.add(gem);
    const halo = new THREE.Mesh(
      new THREE.PlaneGeometry(1.2, 1.2),
      new THREE.MeshBasicMaterial({ color: 0xc684ff, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }),
    );
    halo.position.y = 2.46;
    staff.add(halo);
    this.staff = staff;
    this.gem = gem;
    this.gemMat = gemMat;
    this.halo = halo;
    this.group.add(staff);
    this.staffLight = new THREE.PointLight(0xc684ff, 5, 9, 2);
    scene.add(this.staffLight);
    this.spellLight = new THREE.PointLight(0xffffff, 0, 12, 2);
    scene.add(this.spellLight);
    this.spellLightT = 0;

    this.onStep = null;
    this.stepClock = 0;
  }

  /** Set a spell color on the staff and the light it throws. */
  setStaffColor(hex) {
    this.gemMat.color.set(hex);
    this.halo.material.color.set(hex);
    this.staffLight.color.set(hex);
  }

  /** A flash of light from a cast. */
  flash(hex, power = 1) {
    this.spellLight.color.set(hex);
    this.spellLightT = 0.28 * power;
    this.castLock = Math.max(this.castLock, 0.22);
  }

  /** The world point the staff's gem sits at, for spells that leave the hand. */
  gemPoint(out = new THREE.Vector3()) {
    return this.gem.getWorldPosition(out);
  }

  /** Walk the wizard. move: {x, z} in world space, already turned by the camera. dt in seconds. */
  update(dt, move, camera, mods = {}) {
    const w = this.world;
    const len = Math.hypot(move.x, move.z);
    const sprint = mods.sprint && this.stamina > 1;
    const speed = (sprint ? WALK_SPEED * 1.75 : WALK_SPEED) * (this.castLock > 0 ? 0.45 : 1);
    if (len > 0.01) {
      const dir = new THREE.Vector2(move.x / len, move.z / len);
      // try the diagonal, then slide along each axis, so he walks round trees and up hills
      const step = speed * dt;
      const nx = this.pos.x + dir.x * step, nz = this.pos.z + dir.y * step;
      const tryMove = (x, z) => walkable(w, x, z) && Math.abs(heightAt(w, x, z) - heightAt(w, this.pos.x, this.pos.z)) < 1.6;
      if (tryMove(nx, nz)) { this.pos.x = nx; this.pos.z = nz; }
      else if (tryMove(nx, this.pos.z)) this.pos.x = nx;
      else if (tryMove(this.pos.x, nz)) this.pos.z = nz;
      this.speed = speed;
      // he faces the way he moves
      const want = Math.atan2(dir.x, dir.y);
      let diff = ((want - this.facing + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      this.facing += diff * Math.min(1, dt * 12);
      this.walkClock += dt * (sprint ? 1.7 : 1);
      if (sprint) this.stamina = Math.max(0, this.stamina - dt * 22);
    } else {
      this.speed = 0;
      this.walkClock = 0;
      this.stamina = Math.min(100, this.stamina + dt * 18);
    }
    // footprints and dust
    if (this.speed > 0) {
      this.stepClock += dt;
      if (this.stepClock > (sprint ? 0.22 : 0.3)) {
        this.stepClock = 0;
        this.onStep?.(this.pos.clone(), matAt(w, this.pos.x, this.pos.z));
      }
    }
    // stick to the ground
    const ground = heightAt(w, this.pos.x, this.pos.z);
    this.pos.y += (ground - this.pos.y) * Math.min(1, dt * 14);
    this.group.position.copy(this.pos);

    // the pose
    let pose = "stand";
    if (this.castLock > 0) pose = this.castLock > 0.12 ? "push" : "gather";
    else if (this.speed > 0) pose = Math.floor(this.walkClock / 0.24) % 2 ? "walk1" : "walk2";
    if (pose !== this.poseName) this.mat.map = this.textures[pose];
    this.poseName = pose;
    this.hurtFlash = Math.max(0, this.hurtFlash - dt);
    this.mat.color.setRGB(1, 1 - this.hurtFlash * 0.7, 1 - this.hurtFlash * 0.7);

    // face the camera, like a billboard, but lean into the walk
    this.sprite.rotation.y = Math.atan2(camera.position.x - this.pos.x, camera.position.z - this.pos.z);

    // the staff: held out in front, and it swings when he walks and thrusts when he casts
    const swing = this.castLock > 0 ? -0.55 * Math.min(1, this.castLock / 0.2) : 0;
    const sway = this.speed > 0 ? Math.sin(this.walkClock * 13) * 0.06 : Math.sin(performance.now() * 0.001) * 0.02;
    this.staff.position.set(0.55, 0.05, 0.15);
    this.staff.rotation.set(0.12 + swing + sway, 0, -0.12);

    // lights
    this.staffLight.position.copy(this.gemPoint());
    this.staffLight.intensity = 4 + Math.sin(performance.now() * 0.004) * 1.5 + (this.castLock > 0 ? 10 : 0);
    if (this.spellLightT > 0) {
      this.spellLightT -= dt;
      this.spellLight.intensity = Math.max(0, this.spellLightT / 0.28) * 22;
      this.spellLight.position.copy(this.gemPoint());
    } else this.spellLight.intensity = 0;
    this.castLock = Math.max(0, this.castLock - dt);

    // the halo faces the camera; it lives inside the staff group, so subtract the staff's own yaw
    const gem = this.gemPoint(this._gemTmp ?? (this._gemTmp = new THREE.Vector3()));
    this.halo.rotation.y = Math.atan2(camera.position.x - gem.x, camera.position.z - gem.z) - this.staff.rotation.y - this.group.rotation.y;
    const s = 1 + Math.sin(performance.now() * 0.005) * 0.12;
    this.halo.scale.setScalar(s);

    // mana and shield tick back
    this.mana = Math.min(this.maxMana, this.mana + dt * 7);
    this.hp = Math.min(this.maxHp, this.hp + dt * 0.6);
    this.shield = Math.max(0, this.shield - dt);
    return pose;
  }

  hurt(amount) {
    if (this.shield > 0) return false;
    this.hp = Math.max(0, this.hp - amount);
    this.hurtFlash = 1;
    return true;
  }

  teleportTo(x, z) {
    this.pos.set(x, heightAt(this.world, x, z), z);
    this.group.position.copy(this.pos);
  }
}
