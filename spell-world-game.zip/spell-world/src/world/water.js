// The sea around the island: one plane at sea level that follows the camera, so it reaches the horizon for
// ever; its waves, sparkle and the foam line against the shore are done on the GPU.

import * as THREE from "three";
import { SEA, N } from "./terrain.js";

export function makeWater(scene, cols, C) {
  const span = 1400;
  const geo = new THREE.PlaneGeometry(span, span, 1, 1);
  geo.rotateX(-Math.PI / 2);

  // the island's height, as a texture, so the water knows where the land is (for foam and shallows)
  // the ground under the sea, not the sea surface: that's what tells the water how deep it is
  const data = new Uint8Array(N * N);
  for (let i = 0; i < N * N; i++) data[i] = Math.min(255, Math.max(0, Math.round(cols.ground[i] * 4)));
  const heightTex = new THREE.DataTexture(data, N, N, THREE.RedFormat, THREE.UnsignedByteType);
  heightTex.magFilter = THREE.NearestFilter;
  heightTex.minFilter = THREE.NearestFilter;
  heightTex.needsUpdate = true;

  const uniforms = {
    uTime: { value: 0 },
    uIsland: { value: new THREE.Vector2(N / 2, N / 2) },
    uHeight: { value: heightTex },
    uSea: { value: SEA },
    uDeep: { value: new THREE.Color(C.water[1][0], C.water[1][1], C.water[1][2]) },
    uShallow: { value: new THREE.Color(C.water[4][0], C.water[4][1], C.water[4][2]) },
    uFoam: { value: new THREE.Color(0.62, 0.86, 0.92) },
    uSky: { value: new THREE.Color(C.skyTop[0] * 0.5 + 0.1, C.skyTop[1] * 0.5 + 0.12, C.skyTop[2] * 0.6 + 0.22) },
    uGlint: { value: new THREE.Color(1.0, 0.85, 0.7) },
    uMoon: { value: new THREE.Vector3(1, 0.5, -1).normalize() },
  };

  const mat = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    vertexShader: /* glsl */ `
      varying vec3 vWorld;
      varying vec2 vUv;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorld = wp.xyz;
        vUv = uv;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: /* glsl */ `
      precision highp float;
      varying vec3 vWorld;
      uniform float uTime, uSea;
      uniform vec2 uIsland;
      uniform sampler2D uHeight;
      uniform vec3 uDeep, uShallow, uFoam, uSky, uGlint, uMoon;

      // a few sine waves stacked, cheap and periodic
      float wave(vec2 p, float t) {
        float w = sin(p.x * 0.55 + t * 1.1) * 0.5;
        w += sin(p.y * 0.73 - t * 0.9) * 0.35;
        w += sin((p.x + p.y) * 1.1 + t * 1.7) * 0.18;
        return w;
      }
      float hash(vec2 p) { return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }

      void main() {
        vec2 p = floor(vWorld.xz * 4.0) / 4.0;        // snap to a fine grid: pixel-art sparkle
        float w = wave(p, uTime);
        // how close is the land, and how tall? sample the island height field
        vec2 uvI = (p + uIsland) / ${N}.0;
        float land = 0.0;
        if (uvI.x > 0.0 && uvI.y > 0.0 && uvI.x < 1.0 && uvI.y < 1.0) land = texture2D(uHeight, uvI).r * 4.0;
        float shallow = 1.0 - smoothstep(uSea + 0.2, uSea + 3.5, land);
        float beach = 1.0 - smoothstep(uSea + 0.35, uSea + 1.2, land);
        float depth = smoothstep(0.2, 1.0, 1.0 - shallow);
        vec3 col = mix(uShallow, uDeep, clamp(depth + land * 0.0, 0.0, 1.0));
        // banding: three flat tones, like water in a pixel game
        float band = step(0.25, w) * 0.5 + step(0.6, w) * 0.5;
        col = mix(col, uShallow * 1.25, band * 0.35 * (1.0 - depth));
        // foam: a line of surf where the sea meets the sand, breathing with the swell
        float surf = smoothstep(0.06, 0.0, abs(beach - 0.55 - w * 0.12));
        float sparkle = step(0.86, hash(floor(p * 3.0) + floor(uTime * 3.0))) * smoothstep(-0.2, 0.9, w);
        col = mix(col, uFoam, clamp(surf * 0.85 + sparkle * 0.5, 0.0, 1.0));
        // a glint of warm sky on the swell, towards the sunset
        float glint = pow(max(0.0, dot(normalize(vec3(w * 0.6, 1.0, w * 0.4)), uMoon)), 8.0);
        col += uGlint * glint * 0.25;
        col = mix(col, uSky, 0.3);
        // thick and inky where it's deep, clear enough to see the sand in the shallows
        float alpha = mix(0.62, 0.9, clamp(depth + land * 0.1, 0.0, 1.0));
        gl_FragColor = vec4(col, max(alpha, surf * 0.9));
      }
    `,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(N / 2, SEA + 0.02, N / 2);
  mesh.renderOrder = 1;
  scene.add(mesh);
  return {
    mesh,
    update(t, camPos) {
      uniforms.uTime.value = t;
      // the sea follows the camera in whole steps, so the wave pattern never crawls underfoot
      mesh.position.x = Math.round(camPos.x / 8) * 8;
      mesh.position.z = Math.round(camPos.z / 8) * 8;
    },
  };
}
