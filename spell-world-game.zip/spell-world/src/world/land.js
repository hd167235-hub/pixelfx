// The island on screen: every tile is a flat top quad, plus a real wall on each side where the ground drops.
// Two instanced draw calls for the whole map, shaded in a little GLSL that makes stacked blocks, cliff lips,
// grass overhang, beach skirts and a distance haze.
//
// Walls are only built where a neighbour is lower, so a flat meadow costs nothing and only real ledges are
// drawn; a courtyard cut into a hillside gets facing walls on opposite sides, which a billboard can't do.

import * as THREE from "three";
import { N, SEA, M } from "./terrain.js";
import { C, rampOf } from "./columns.js";

const RAMP_SIZE = 8;
const RAMP_ROWS = [M.DEEP, M.WATER, M.SAND, M.GRASS, M.DIRT, M.ROCK, M.SNOW, M.PATH, M.ASH];

// every material's ramp, padded to 8 steps, as one small texture the shader samples
function rampTexture() {
  const data = new Uint8Array(RAMP_ROWS.length * RAMP_SIZE * 4);
  RAMP_ROWS.forEach((mat, row) => {
    const ramp = rampOf(mat);
    for (let k = 0; k < RAMP_SIZE; k++) {
      const c = ramp[Math.min(ramp.length - 1, Math.round((k / (RAMP_SIZE - 1)) * (ramp.length - 1)))];
      const o = (row * RAMP_SIZE + k) * 4;
      data[o] = Math.round(c[0] * 255);
      data[o + 1] = Math.round(c[1] * 255);
      data[o + 2] = Math.round(c[2] * 255);
      data[o + 3] = 255;
    }
  });
  const tex = new THREE.DataTexture(data, RAMP_SIZE, RAMP_ROWS.length, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.needsUpdate = true;
  return tex;
}

// shared GLSL: palette lookup, distance haze, ordered dither. No varyings here: each shader declares its own.
const COMMON = /* glsl */ `
  precision highp float;
  uniform sampler2D uRamps;
  uniform vec3 uFog, uSkyLow, uGlow;
  uniform vec4 uRune;     // a spell circle on the ground: x, z, radius, strength
  uniform float uTime, uSea;

  vec3 rampOf(float mat, float level) {
    float v = 1.0 - clamp(level, 0.0, 1.0);
    float row = floor(mat + 0.5);
    float col = floor(v * ${(RAMP_SIZE - 1).toFixed(1)} + 0.5);
    return texture2D(uRamps, vec2((col + 0.5) / ${RAMP_SIZE.toFixed(1)}, (row + 0.5) / ${RAMP_ROWS.length.toFixed(1)})).rgb;
  }
  // 4x4 ordered dithering, built from two 2x2 checks (no arrays, so it compiles on any GLSL ES)
  float bayer2(vec2 a) { a = floor(a); return fract(a.x / 2.0 + a.y * a.y * 0.75); }
  float bayer(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }
  vec3 haze(vec3 col, float d) {
    float k = smoothstep(55.0, 210.0, d);
    vec3 fog = mix(uFog, uSkyLow, 0.3 + 0.4 * clamp((d - 80.0) / 240.0, 0.0, 1.0));
    return mix(col, fog, k * 0.85);
  }
  float hash1(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
`;

export function makeLand(scene, cols) {
  const total = cols.total;
  let wallGeomCount = 0;

  const uniforms = {
    uRamps: { value: rampTexture() },
    uFog: { value: new THREE.Color(C.fog[0], C.fog[1], C.fog[2]) },
    uSkyLow: { value: new THREE.Color(C.skyLow[0], C.skyLow[1], C.skyLow[2]) },
    uGlow: { value: new THREE.Color(C.skyGlow[0], C.skyGlow[1], C.skyGlow[2]) },
    uTime: { value: 0 },
    uSea: { value: SEA },
    uCamPos: { value: new THREE.Vector3() },
    uRune: { value: new THREE.Vector4(0, 0, 1, 0) },
  };

  // ---- the cliffs: a real wall on each of the four sides, built only where the ground actually drops.
  // North and south walls face the -z / +z way, east and west walls the -x / +x way, so the island is a solid
  // voxel body from any angle instead of a set of billboards that leave gaps between them.
  const sides = new Uint16Array(total * 4);      // how many of the four walls each tile has
  let wallCount = 0;
  for (let z = 0; z < N; z++)
    for (let x = 0; x < N; x++) {
      const i = z * N + x;
      const top = cols.top[i];
      const drop = [top - cols.hN[i], top - cols.hS[i], top - cols.hE[i], top - cols.hW[i]];
      let n = 0;
      for (let k = 0; k < 4; k++) if (drop[k] > 0.4) n++;
      sides[i * 4] = n;
      if (n) wallCount++;
    }
  const quadCount = total * 4;
  const wPos = new Float32Array(quadCount * 4 * 3);      // four corners per wall, in world space
  const wCol = new Float32Array(quadCount * 4 * 3);      // the same corners' colour attributes
  const wInfo = new Float32Array(quadCount * 4 * 4);     // material, top, foot, jitter
  const wIdx = new Uint32Array(quadCount * 6);
  {
    let q = 0;
    const emit = (i, dir, a, b, top, foot, mat, jit, shore) => {
      const base = q * 4;
      // two corners on the ground plane (a and b), each repeated at the top and at the foot, so the wall's
      // shading can tell the lip from the base
      const corn = [
        [a[0], top, a[1]], [b[0], top, b[1]],
        [b[0], foot, b[1]], [a[0], foot, a[1]],
      ];
      for (let k = 0; k < 4; k++) {
        const o = (base + k) * 3;
        wPos[o] = corn[k][0]; wPos[o + 1] = corn[k][1]; wPos[o + 2] = corn[k][2];
        wCol[o] = a[0]; wCol[o + 1] = a[1]; wCol[o + 2] = dir;   // the tile's x, z and the side's index
        const m = (base + k) * 4;
        wInfo[m] = mat; wInfo[m + 1] = top; wInfo[m + 2] = foot; wInfo[m + 3] = jit + shore * 4;
      }
      const ii = q * 6;
      wIdx[ii] = base; wIdx[ii + 1] = base + 1; wIdx[ii + 2] = base + 2;
      wIdx[ii + 3] = base; wIdx[ii + 4] = base + 2; wIdx[ii + 5] = base + 3;
      q++;
    };
    for (let z = 0; z < N; z++)
      for (let x = 0; x < N; x++) {
        const i = z * N + x;
        const top = cols.top[i], mat = cols.mat[i], jit = cols.jitter[i], shore = cols.shore[i];
        const nb = [cols.hN[i], cols.hS[i], cols.hE[i], cols.hW[i]];
        // the four sides, clockwise from north: each is the edge of the tile's footprint
        const edges = [
          [[x, z], [x + 1, z]],             // north
          [[x + 1, z + 1], [x, z + 1]],     // south
          [[x + 1, z], [x + 1, z + 1]],     // east
          [[x, z + 1], [x, z]],             // west
        ];
        for (let d = 0; d < 4; d++) {
          const foot = nb[d];
          if (top - foot <= 0.4) continue;
          emit(i, d, edges[d][0], edges[d][1], top, foot, mat, jit, shore);
        }
      }
    wallGeomCount = q;
  }
  const wallGeom = new THREE.BufferGeometry();
  wallGeom.setAttribute("position", new THREE.BufferAttribute(wPos, 3));
  wallGeom.setAttribute("aTile", new THREE.BufferAttribute(wCol, 3));
  wallGeom.setAttribute("aInfo", new THREE.BufferAttribute(wInfo, 4));
  wallGeom.setIndex(new THREE.BufferAttribute(wIdx, 1));
  wallGeom.setDrawRange(0, wallGeomCount * 6);

  const wallMat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: /* glsl */ `
      precision highp float;
      attribute vec3 aTile;      // tile x, tile z, side index (0..3)
      attribute vec4 aInfo;      // material, top, foot, jitter (+4 for a beach)
      uniform vec3 uCamPos;
      varying vec3 vWorld;
      varying vec4 vInfo;
      varying float vShore, vDist;
      void main() {
        vWorld = position;
        vInfo = aInfo;
        vShore = aInfo.w > 2.0 ? 1.0 : 0.0;
        vDist = length(position - uCamPos);
        gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      ${COMMON}
      varying vec3 vWorld;
      varying vec4 vInfo;
      varying float vShore, vDist;
      void main() {
        float mat = vInfo.x;
        float top = vInfo.y;
        float foot = vInfo.z;
        float jit = vInfo.w - vShore * 4.0;
        float y = vWorld.y;
        // how far down the face: 0 at the lip, 1 at the base
        float drop = clamp((top - y) / max(0.001, top - foot + 2.0), 0.0, 1.0);
        float band = floor(y);
        float inBand = fract(y);
        float seam = smoothstep(0.0, 0.1, inBand) * smoothstep(0.0, 0.13, 1.0 - inBand);

        // the cliff, top to bottom: the surface's material, then soil, then stone at the base
        vec3 col;
        if (drop < 0.2) col = rampOf(mat, 0.08 + drop * 2.0);
        else if (drop < 0.62) col = mix(rampOf(${M.GRASS}.0, (drop - 0.2) * 2.0), rampOf(${M.DIRT}.0, 0.2), 0.45);
        else col = rampOf(${M.ROCK}.0, 0.15 + (drop - 0.62) * 1.6);
        if (vShore > 0.5) col = mix(col, rampOf(${M.SAND}.0, 0.1 + drop * 1.6), 0.8);

        // stacked courses: each block a shade apart, with a dark joint between them
        col *= 0.88 + 0.14 * hash1(vec2(band, vWorld.x + vWorld.z * 7.0));
        col = mix(col, col * 0.62, (1.0 - seam) * 0.5);
        if (inBand > 0.8) col *= 1.08;

        // the lip of grass hanging over the edge of the drop, ragged with the tile's jitter
        if (drop < 0.1 + 0.04 * jit && mat > 2.5 && mat < 4.5) col = rampOf(mat, 0.0) * (1.05 + 0.1 * jit);

        // ambient occlusion: the base of the cliff sits in shadow
        col *= 0.72 + 0.28 * (1.0 - drop);

        // a spell circle lights the ground it touches
        float d = length(vWorld.xz - uRune.xy);
        col += uGlow * uRune.w * (1.0 - smoothstep(0.0, max(uRune.z, 0.001), d)) * (0.6 + 0.4 * sin(uTime * 3.0 + d * 0.8)) * 0.5;

        col = haze(col, vDist);
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const walls = new THREE.Mesh(wallGeom, wallMat);
  walls.frustumCulled = false;
  walls.renderOrder = 3;
  scene.add(walls);

  // ---- the tops: one flat quad per tile, at its height
  const wTile = new Float32Array(total * 2);
  for (let z = 0; z < N; z++) for (let x = 0; x < N; x++) { wTile[(z * N + x) * 2] = x; wTile[(z * N + x) * 2 + 1] = z; }
  const topGeom = new THREE.InstancedBufferGeometry();
  topGeom.setAttribute("position", new THREE.BufferAttribute(new Float32Array([0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1]), 3));
  topGeom.setAttribute("uv", new THREE.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2));
  topGeom.setIndex([0, 1, 2, 0, 2, 3]);
  const tTop = new Float32Array(total), tMat = new Float32Array(total), tJit = new Float32Array(total);
  const tN = new Float32Array(total), tS = new Float32Array(total), tE = new Float32Array(total), tW = new Float32Array(total);
  for (let i = 0; i < total; i++) {
    tTop[i] = cols.top[i];
    tMat[i] = cols.mat[i];
    tN[i] = cols.hN[i]; tS[i] = cols.hS[i]; tE[i] = cols.hE[i]; tW[i] = cols.hW[i];
    tJit[i] = cols.jitter[i];
  }
  const tset = (name, arr, size) => topGeom.setAttribute(name, new THREE.InstancedBufferAttribute(arr, size));
  topGeom.setAttribute("aTile", new THREE.InstancedBufferAttribute(wTile, 2));
  tset("aTop", tTop, 1);
  tset("aMat", tMat, 1);
  tset("aHN", tN, 1);
  tset("aHS", tS, 1);
  tset("aHE", tE, 1);
  tset("aHW", tW, 1);
  tset("aJit", tJit, 1);
  topGeom.instanceCount = total;
  topGeom.boundingSphere = new THREE.Sphere(new THREE.Vector3(N / 2, 18, N / 2), N);

  const topMat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: /* glsl */ `
      precision highp float;
      attribute float aTop, aMat, aHN, aHS, aHE, aHW, aJit;
      attribute vec2 aTile;
      uniform vec3 uCamPos;
      varying vec3 vWorld;
      varying vec4 vInfo;     // material, jitter, north height, south height
      varying vec2 vUv;
      varying vec2 vSide;     // east and west heights
      varying float vDist;
      void main() {
        vec3 p = vec3(aTile.x + position.x, aTop, aTile.y + position.z);
        vWorld = p;
        vInfo = vec4(aMat, aJit, aHN, aHS);
        vSide = vec2(aHE, aHW);
        vUv = uv;
        vDist = length(p - uCamPos);
        gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      ${COMMON}
      varying vec3 vWorld;
      varying vec4 vInfo;
      varying vec2 vUv;
      varying vec2 vSide;
      varying float vDist;
      void main() {
        float mat = vInfo.x;
        float jit = vInfo.y;
        float top = vWorld.y;
        if (mat < 1.5) discard;          // sea floor: the sea is drawn over it
        vec3 col = rampOf(mat, 0.05);
        // two tones dithered together: flat ground without dead flat colour
        col *= 0.95 + 0.1 * bayer(vWorld.xz * 2.0);
        col *= 0.96 + 0.08 * hash1(floor(vWorld.xz * 0.5));
        // the rim of a raised block: bare soil and the shade of the drop beyond it
        float edge = 0.0;
        if (vInfo.z < top - 0.5 && vUv.y < 0.05) edge = 1.0;
        if (vInfo.w < top - 0.5 && vUv.y > 0.95) edge = 1.0;
        if (vSide.x < top - 0.5 && vUv.x > 0.95) edge = 1.0;
        if (vSide.y < top - 0.5 && vUv.x < 0.05) edge = 1.0;
        col = mix(col, rampOf(${M.DIRT}.0, 0.5) * 0.72, edge * 0.6);
        // peaks take a pale rim so they lift out of the haze
        if (mat > 4.5) col = mix(col, rampOf(mat, 0.0), 0.2 + 0.2 * jit);
        // light from a spell circle, and from the sea
        float d = length(vWorld.xz - uRune.xy);
        col += uGlow * uRune.w * (1.0 - smoothstep(0.0, max(uRune.z, 0.001), d)) * (0.65 + 0.35 * sin(uTime * 3.0 + d * 0.8));
        float sea = 1.0 - smoothstep(${(SEA + 0.2).toFixed(1)}, ${(SEA + 1.5).toFixed(1)}, top);
        col = mix(col, col * 0.6 + vec3(0.0, 0.03, 0.06), sea * 0.7);
        col = haze(col, vDist);
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const tops = new THREE.Mesh(topGeom, topMat);
  tops.frustumCulled = false;
  tops.renderOrder = 4;
  // lift the ground a hair off the depth of the cliff faces and the props standing on it
  tops.position.y = 0.04;
  scene.add(tops);

  return {
    wall: walls,
    tops,
    uniforms,
    update(t, camera) {
      uniforms.uTime.value = t;
      uniforms.uCamPos.value.copy(camera.position);
    },
    setRune(x, z, radius, strength) {
      uniforms.uRune.value.set(x, z, radius, strength);
    },
  };
}
