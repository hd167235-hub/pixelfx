// The sky: a sunset gradient on a big inverted sphere, with twinkling stars, a low warm sun and two moons,
// plus a little drifting cloud to give the horizon some depth.

import * as THREE from "three";
import { C } from "./columns.js";

export function makeSky(scene) {
  const uniforms = {
    uTime: { value: 0 },
    uTop: { value: new THREE.Color(C.skyTop[0], C.skyTop[1], C.skyTop[2]) },
    uMid: { value: new THREE.Color(C.skyMid[0], C.skyMid[1], C.skyMid[2]) },
    uLow: { value: new THREE.Color(C.skyLow[0], C.skyLow[1], C.skyLow[2]) },
    uGlow: { value: new THREE.Color(C.skyGlow[0], C.skyGlow[1], C.skyGlow[2]) },
    uSun: { value: new THREE.Color(C.sun[0], C.sun[1], C.sun[2]) },
    uStars: { value: new THREE.Color(0.9, 0.88, 1.0) },
    uDay: { value: 0 },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    vertexShader: /* glsl */ `
      varying vec3 vDir;
      void main() {
        vDir = normalize(position);
        vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        gl_Position = p;
        gl_Position.z = gl_Position.w;      // always at the far plane
      }
    `,
    fragmentShader: /* glsl */ `
      precision highp float;
      varying vec3 vDir;
      uniform float uTime, uDay;
      uniform vec3 uTop, uMid, uLow, uGlow, uSun, uStars;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      void main() {
        vec3 d = normalize(vDir);
        // a sunset: deep ink overhead, violet in the middle, a burning band at the horizon
        float y = clamp(d.y, -1.0, 1.0);
        vec3 col = mix(uLow, uMid, smoothstep(0.0, 0.34, y));
        col = mix(col, uTop, smoothstep(0.22, 0.95, y));
        // the sun sits low in the west-north-west, and paints the sky around it
        vec3 sunDir = normalize(vec3(-0.55, 0.07, -0.83));
        float sd = max(0.0, dot(d, sunDir));
        col += uGlow * pow(sd, 6.0) * 0.75;
        col += uSun * pow(sd, 90.0) * 1.4;
        // and below the horizon it settles into the sea haze
        col = mix(col, uLow * 0.65, 1.0 - smoothstep(-0.22, 0.06, y));
        // stars: a hash grid that twinkles, only high up and only where the sun doesn't wash them out
        if (y > 0.06) {
          vec2 g = floor(vec2(atan(d.z, d.x) * 60.0, y * 90.0));
          float r = hash(g);
          if (r > 0.985) {
            float tw = 0.55 + 0.45 * sin(uTime * 3.0 + r * 40.0);
            float fade = smoothstep(0.08, 0.4, y) * (1.0 - pow(sd, 3.0));
            col += uStars * tw * fade * 0.9;
          }
        }
        // a pale moon, and a small pink companion
        vec3 moonDir = normalize(vec3(0.45, 0.55, 0.7));
        float md = dot(d, moonDir);
        float moon = smoothstep(0.9975, 0.9985, md);
        col = mix(col, vec3(1.0, 0.94, 0.82), moon * 0.95);
        col += vec3(0.9, 0.8, 0.7) * smoothstep(0.985, 0.999, md) * 0.25;
        vec3 moon2 = normalize(vec3(0.15, 0.72, 0.66));
        float m2 = smoothstep(0.99935, 0.99965, dot(d, moon2));
        col = mix(col, vec3(1.0, 0.62, 0.86), m2 * 0.9);
        // a fine dither, so the gradient reads as pixel art rather than a smooth wash
        float b = mod(floor(gl_FragCoord.x) + floor(gl_FragCoord.y) * 2.0, 4.0) / 4.0;
        col += (b - 0.5) * 0.012;
        if (uDay > 0.5) col = mix(col, vec3(0.55, 0.75, 0.95), 0.55);
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 32, 20), mat);
  sky.frustumCulled = false;
  sky.renderOrder = -10;
  scene.add(sky);

  // drifting cloud banks, low and wide: a handful of soft dark quads near the horizon
  const clouds = new THREE.Group();
  const cloudMat = new THREE.MeshBasicMaterial({ color: 0x2a1f3d, transparent: true, opacity: 0.55, depthWrite: false, fog: false, toneMapped: false });
  for (let i = 0; i < 14; i++) {
    const w = 60 + (i * 37) % 90, h = 8 + (i * 13) % 14;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), cloudMat);
    const a = (i / 14) * Math.PI * 2 + (i % 3) * 0.2;
    m.position.set(Math.cos(a) * 300, 30 + (i % 5) * 9, Math.sin(a) * 300);
    m.lookAt(0, 30, 0);
    clouds.add(m);
  }
  clouds.renderOrder = -9;
  scene.add(clouds);

  return {
    sky,
    update(t, camPos) {
      uniforms.uTime.value = t;
      sky.position.copy(camPos);
      clouds.position.set(camPos.x, 0, camPos.z);
      clouds.rotation.y = t * 0.004;
    },
  };
}
