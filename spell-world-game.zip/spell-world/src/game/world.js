// The world, assembled: terrain, sea, sky, dressing, lights, and the spells that live in it.

import * as THREE from "three";
import { makeWorld, heightAt, matAt, walkable, N, SEA, MATS } from "../world/terrain.js";
import { makeColumns, C } from "../world/columns.js";
import { makeLand } from "../world/land.js";
import { makeWater } from "../world/water.js";
import { makeSky } from "../world/sky.js";
import { makeDressing } from "../world/dressing.js";
import { EffectPool } from "../fx3d/effect.js";
import { Wizard } from "../player/wizard.js";
import { Wanderers } from "../world/wanderers.js";
import { SPELLBOOK, SPELL_LIST } from "../spells/catalog.js";
import * as firefliesMod from "../../../src/fx/weather/fireflies.js";
import * as auroraMod from "../../../src/fx/weather/aurora.js";
import * as magicCircleMod from "../../../src/fx/arcane/magic-circle-cast.js";

export class SpellWorld {
  constructor(canvas, seed = 1337) {
    this.canvas = canvas;
    this.seed = seed;
    this.listeners = {};
    this.setupRenderer();
    this.build(seed);
  }

  on(name, fn) { (this.listeners[name] ??= []).push(fn); return this; }
  emit(name, ...args) { for (const fn of this.listeners[name] ?? []) fn(...args); }

  setupRenderer() {
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.NoToneMapping;
    this.camera = new THREE.PerspectiveCamera(40, 16 / 9, 0.5, 1200);
    // a low, raking third-person view: the sun behind the island, the sea at your back
    this.orbit = { yaw: 0.62, pitch: 0.34, dist: 17, targetYaw: 0.62, targetPitch: 0.34, targetDist: 17 };
    this.resize();
  }

  resize() {
    const rect = this.canvas.parentElement.getBoundingClientRect();
    const scale = this.pixelScale ?? 1;
    const aspect = Math.max(0.6, rect.width / Math.max(1, rect.height));
    // a chunky internal resolution: about 480 lines tall, whatever the window
    const h = Math.max(180, Math.min(540, Math.round((rect.height * scale) / 2) * 2));
    const w = Math.round((h * aspect) / 2) * 2;
    this.renderer.setSize(w, h, false);
    this.canvas.style.width = "100%";
    this.canvas.style.height = "100%";
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.pixel = { w, h };
  }

  /** Tear the old island down and raise a new one. */
  build(seed) {
    this.seed = seed;
    if (this.scene) this.disposeWorld();
    const scene = new THREE.Scene();
    this.scene = scene;
    this.world = makeWorld(seed);
    const f = this.world.features;
    this.cols = makeColumns(this.world);
    this.land = makeLand(scene, this.cols, this.world);
    this.water = makeWater(scene, C);
    this.sky = makeSky(scene);
    this.dressing = makeDressing(scene, this.world, this.cols);
    this.wanderers = new Wanderers(scene, this.world, this.cols);
    this.fx = new EffectPool(scene);
    this.fx.limit = 26;      // the spell effects, not the ambience, count against the cap
    this.ambient = [];

    // the moon lights the island: a cool key light, and a warm one from the sunset side
    const key = new THREE.DirectionalLight(0x9fb4ff, 0.55);
    key.position.set(-30, 60, 40);
    scene.add(key);
    const warm = new THREE.DirectionalLight(0xff9a6a, 0.85);
    warm.position.set(-70, 12, -80);
    scene.add(warm);
    scene.add(new THREE.HemisphereLight(0x6a5aa8, 0x14202e, 0.9));

    this.wizard = new Wizard(scene, this.world, f.spawn);
    this.wizard.onStep = (pos, mat) => {
      // little puffs of dust from the ground he walks on
      const p = pos.clone();
      p.y += 0.15;
      // a tiny puff of dust in the ground's own colours
      const gs = SPELLBOOK.poof;
      const dust = mat === 2 ? ["#6e5539", "#8f6f48", "#ad8a5c", "#c8a475", "#dcc191"] : ["#2b3327", "#3d4a33", "#56664a", "#75886a", "#9caf90"];
      this.fx.spawn(gs.mod, p, { scale: 0.022, glow: 0.6, opts: { palette: dust } });
    };

    // ambient life: fireflies in the meadow, a wisp by the stones, an aurora over the northern sea
    const add = (mod, at, opts) => {
      const fx = this.fx.spawn(mod, at, opts, { ambient: true });
      this.ambient.push(fx);
      return fx;
    };
    add(firefliesMod, new THREE.Vector3(f.ring.x - 6, f.ring.y + 0.2, f.ring.z + 3), { scale: 0.09, glow: 1.4, opts: { seed: seed % 9 } });
    const aurora = add(auroraMod, new THREE.Vector3(N * 0.5, SEA + 42, 12), { scale: 0.62, glow: 0.9 });
    aurora.group.rotation.y = Math.PI;

    this.time = 0;
    this.cooldowns = {};
    this.quest = { done: false };
    this.portalLink = null;
    this.stats = { casts: 0, discovered: new Set() };
    this.camPos = new THREE.Vector3(f.spawn.x, f.spawn.y + 10, f.spawn.z + 14);
    this.emit("world", this.world);
    this.placeCamera(1);
  }

  disposeWorld() {
    // only free what this world made: the dressing's props own their planes and materials, so a rebuild
    // from a new seed doesn't take the shared sprite textures down with it
    this.fx?.clear();
    this.wanderers?.dispose();
    this.dressing?.group?.traverse((o) => {
      if (!o.userData.own) return;
      o.geometry?.dispose?.();
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) m?.dispose?.();
    });
    for (const m of [this.land?.wall, this.land?.tops, this.water?.mesh, this.sky?.sky]) {
      if (!m) continue;
      m.geometry?.dispose?.();
      m.material?.dispose?.();
      this.scene.remove(m);
    }
    this.scene = null;
  }

  /** Where the camera should sit this frame, easing towards the orbit the player asked for. */
  placeCamera(k = 0.15) {
    const o = this.orbit;
    o.yaw += (o.targetYaw - o.yaw) * k;
    o.pitch += (o.targetPitch - o.pitch) * k;
    o.dist += (o.targetDist - o.dist) * k;
    const p = this.wizard.pos;
    const cx = p.x + Math.sin(o.yaw) * Math.cos(o.pitch) * o.dist;
    const cz = p.z + Math.cos(o.yaw) * Math.cos(o.pitch) * o.dist;
    const cy = p.y + 3.2 + Math.sin(o.pitch) * o.dist;
    // don't let the camera sink into a hill
    const gh = heightAt(this.world, cx, cz) + 2.2;
    this.camPos.set(cx, Math.max(cy, gh), cz);
    this.camera.position.copy(this.camPos);
    const look = new THREE.Vector3(p.x, p.y + 1.1, p.z);
    this.camera.lookAt(look);
  }

  /** The forward direction on the ground, from the camera towards the wizard. */
  forward() {
    const d = new THREE.Vector2(-Math.sin(this.orbit.yaw), -Math.cos(this.orbit.yaw));
    return d.normalize();
  }
  right() {
    const f = this.forward();
    return new THREE.Vector2(-f.y, f.x);
  }

  /** Ray from the camera through a screen point, marched until it hits the ground. */
  aimPoint(ndcX, ndcY) {
    const ray = new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.camera);
    const o = ray.ray.origin, d = ray.ray.direction;
    let prev = o.y - heightAt(this.world, o.x, o.z), hit = null;
    for (let t = 1; t < 320; t += 0.6) {
      const x = o.x + d.x * t, y = o.y + d.y * t, z = o.z + d.z * t;
      const h = Math.max(heightAt(this.world, x, z), SEA);
      if (y <= h) {
        // refine
        let a = t - 0.6, b = t;
        for (let k = 0; k < 8; k++) {
          const m = (a + b) / 2;
          const my = o.y + d.y * m, mh = Math.max(heightAt(this.world, o.x + d.x * m, o.z + d.z * m), SEA);
          if (my <= mh) b = m; else a = m;
        }
        hit = new THREE.Vector3(o.x + d.x * b, Math.max(heightAt(this.world, o.x + d.x * b, o.z + d.z * b), SEA), o.z + d.z * b);
        break;
      }
    }
    if (!hit) {
      // the sky: aim at a point the spell's range away, along the ray
      const t = 30;
      hit = new THREE.Vector3(o.x + d.x * t, Math.max(heightAt(this.world, o.x + d.x * t, o.z + d.z * t), SEA), o.z + d.z * t);
    }
    return hit;
  }

  /** Cast a spell by id. aim: a THREE.Vector3 on the ground. */
  cast(id, aim) {
    const spell = SPELLBOOK[id];
    if (!spell) return null;
    const w = this.wizard;
    if (w.mana < spell.cost) {
      this.emit("notice", "Not enough mana", "bad");
      return null;
    }
    const cd = this.cooldowns?.[id] ?? 0;
    if (cd > 0) return null;
    (this.cooldowns ??= {})[id] = spell.cooldown;
    w.mana -= spell.cost;
    w.flash(spell.light, 1);
    w.setStaffColor(spell.light);
    this.stats.casts++;
    this.stats.discovered.add(id);
    this.wanderers?.startle(at.x, at.z, spell.cost > 20 ? 12 : 7);
    this.emit("cast", spell);
    if (spell.shake) this.camShake = Math.max(this.camShake ?? 0, spell.shake * 0.45);

    const fwd = this.forward();
    const p = w.pos;
    const hand = w.gemPoint(new THREE.Vector3());
    const at = aim ? aim.clone() : p.clone();
    // a small magic circle draws itself at the caster's feet: every real spell visibly starts from him
    if (spell.cost >= 10) this.fx.spawn(magicCircleMod, new THREE.Vector3(p.x, Math.max(heightAt(this.world, p.x, p.z), SEA) + 0.02, p.z), {
      scale: 0.026, glow: 0.9, hold: 0.1,
      opts: { palette: schoolRamp(spell), seed: 3 },
    });
    const groundY = (x, z) => Math.max(heightAt(this.world, x, z), SEA);

    switch (spell.castAt) {
      case "hand": {
        if (spell.portal) break;
        const dir = new THREE.Vector2(at.x - hand.x, at.z - hand.z).normalize();
        if (!Number.isFinite(dir.x) || (dir.x === 0 && dir.y === 0)) dir.set(fwd.x, fwd.y);
        const travel = spell.travel ?? { speed: 10, range: 14 };
        // the effect's canvas is drawn facing right: turn it to the way it flies
        const fx = this.fx.spawn(spell.mod, hand, { scale: spell.scale, glow: 1.3, opts: { seed: Math.floor(Math.random() * 9) + 1 } });
        fx.group.rotation.y = Math.atan2(dir.x, dir.y) - Math.PI / 2;
        fx.group.rotation.z = 0;
        this.travel = { fx, dir, left: Math.min(travel.range, 32), speed: travel.speed, arc: travel.arc ?? 0, spell, start: hand.clone() };
        break;
      }
      case "ahead": {
        const a = p.clone();
        a.x += fwd.x * 3.2;
        a.z += fwd.y * 3.2;
        const y = groundY(a.x, a.z);
        a.y = y;
        if (spell.portal) {
          if (this.portalLink) {
            // step through: the first portal takes you to the second
            const from = this.portalLink.pos.clone();
            this.fx.spawn(SPELLBOOK.poof.mod, w.pos.clone(), { scale: 0.05 });
            w.teleportTo(this.portalLink.pos.x, this.portalLink.pos.z);
            this.fx.spawn(SPELLBOOK.warpIn.mod, w.pos.clone().setY(w.pos.y + 0.2), { scale: 0.05 });
            this.fx.spawn(SPELLBOOK.poof.mod, from, { scale: 0.06 });
            this.portalLink.fx.dispose();
            this.portalLink = null;
            this.emit("notice", "You step through the rift", "good");
            break;
          }
          const fx = this.fx.spawn(spell.mod, a, { scale: spell.scale, glow: 1.6, hold: 4 });
          fx.group.rotation.y = Math.atan2(fwd.x, fwd.y);
          this.portalLink = { pos: a, fx };
          this.emit("notice", "A rift opens — cast again to step through", "good");
          break;
        }
        const fx = this.fx.spawn(spell.mod, a, { scale: spell.scale, glow: 1.3 });
        fx.group.rotation.y = Math.atan2(fwd.x, fwd.y);
        break;
      }
      case "self": {
        if (spell.shield) w.shield = spell.shield;
        if (spell.heal) w.hp = Math.min(w.maxHp, w.hp + spell.heal);
        if (spell.blink) {
          const dest = new THREE.Vector2(p.x + fwd.x * spell.blink, p.z + fwd.y * spell.blink);
          if (walkable(this.world, dest.x, dest.y)) {
            this.fx.spawn(SPELLBOOK.poof.mod, p.clone(), { scale: 0.05 });
            w.teleportTo(dest.x, dest.y);
            this.fx.spawn(spell.mod, w.pos.clone(), { scale: spell.scale, glow: 1.4 });
            break;
          }
          this.emit("notice", "Nothing to blink onto there", "bad");
        }
        const fx = this.fx.spawn(spell.mod, p.clone(), { scale: spell.scale, glow: 1.3, hold: spell.hold ?? 0 });
        // body effects sit over the wizard
        fx.group.position.y += 0.2;
        break;
      }
      default: {
        // ground, sky, air: anchored where the player aimed
        const a = at.clone();
        if (spell.castAt === "air") a.y += 3.4;
        else a.y = groundY(a.x, a.z) + (spell.castAt === "sky" ? 0 : 0.05);
        const fx = this.fx.spawn(spell.mod, a, { scale: spell.scale, glow: 1.3, hold: spell.hold ?? 0, opts: { seed: Math.floor(Math.random() * 9) + 1 } });
        fx.group.rotation.y = Math.atan2(fwd.x, fwd.y);
        this.aimMarker?.(a, spell);
        break;
      }
    }
    this.land.setRune(at.x, at.z, 9, 0.35);
    this.runeT = 0.8;
    return spell;
  }

  /** Advance everything by dt seconds. input: { move: {x,z}, aim: Vector3 }. */
  update(dt, input) {
    this.time += dt;
    // cooldowns
    for (const k of Object.keys(this.cooldowns ?? {})) this.cooldowns[k] = Math.max(0, this.cooldowns[k] - dt);
    // the player
    const move = input.move;
    this.wizard.update(dt, move, this.camera, { sprint: input.sprint });

    // the flying spell, if any
    if (this.travel) {
      const tr = this.travel;
      const step = Math.min(tr.left, tr.speed * dt);
      tr.left -= step;
      tr.fx.group.position.addScaledVector(new THREE.Vector3(tr.dir.x, 0, tr.dir.y), step);
      tr.fx.group.position.y = Math.max(heightAt(this.world, tr.fx.group.position.x, tr.fx.group.position.z), SEA) + 1.5;
      if (tr.arc) tr.fx.group.position.y += Math.sin((1 - tr.left / (tr.speed * 2)) * Math.PI) * tr.arc;
      tr.fx.group.position.y += Math.sin(this.time * 20) * 0.03;
      if (tr.left <= 0.01) {
        const p = tr.fx.group.position.clone();
        tr.fx.dispose();
        this.fx.spawn(SPELLBOOK.poof.mod, p, { scale: 0.06, glow: 1.2 });
        this.travel = null;
      }
    }

    // effects, ambience, dressing, land
    this.fx.update(dt);
    this.land.update(this.time, this.camera);
    this.water.update(this.time, this.camera.position);
    this.sky.update(this.time, this.camera.position);
    this.dressing.update(this.time, this.camera);
    this.wanderers.update(dt, this.time, this.camera);
    if (this.runeT > 0) {
      this.runeT -= dt;
      if (this.runeT <= 0) this.land.setRune(0, 0, 1, 0);
    }
    this.camShake = Math.max(0, (this.camShake ?? 0) - dt * 2.2);

    this.placeCamera(1 - Math.pow(0.0001, dt));
    if (this.camShake > 0) {
      const k = this.camShake * 0.25;
      this.camera.position.x += (Math.random() - 0.5) * k;
      this.camera.position.y += (Math.random() - 0.5) * k;
    }

    // quest: find the gate
    if (!this.quest.done && this.dressing.gate) {
      const d = this.wizard.pos.distanceTo(this.dressing.gate.pos);
      this.quest.distance = d;
      if (d < 4.5) {
        this.quest.done = true;
        this.emit("quest");
      }
    }
    this.renderer.render(this.scene, this.camera);
  }

  shake_(k) { this.camShake = Math.max(this.camShake ?? 0, k); }

  rotate(dYaw, dPitch) {
    this.orbit.targetYaw += dYaw;
    this.orbit.targetPitch = Math.min(1.15, Math.max(0.08, this.orbit.targetPitch + dPitch));
  }
  zoom(d) {
    this.orbit.targetDist = Math.min(42, Math.max(7, this.orbit.targetDist + d));
  }
}

/** A ramp per school, for the little magic circle at the caster's feet. */
const SCHOOL_RAMP = {
  fire: ["#4a1712", "#8a1f17", "#c9281f", "#f2561d", "#ff8a2a", "#ffc23d", "#ffe26b", "#fff3a6"],
  ice: ["#151a3d", "#212f6b", "#2c58aa", "#3a8bd8", "#62c8f4", "#a6ecff", "#dcfbff", "#ffffff"],
  lightning: ["#0a0f2e", "#172a78", "#2550d0", "#3f8cff", "#7cc8ff", "#c8f0ff", "#ffffff"],
  holy: ["#2a1c08", "#5a3e10", "#9a6c18", "#d8a428", "#ffd84a", "#fff09a", "#fffbe6", "#ffffff"],
  shadow: ["#050308", "#0f0a18", "#1c1230", "#2c1a4a", "#432468", "#5e3290", "#8048b8", "#a970e0"],
  nature: ["#0c1a0e", "#163418", "#225224", "#357530", "#4f9a3a", "#7cc048", "#b4e070", "#e4ffb0"],
  arcane: ["#140a26", "#2b1252", "#481c88", "#6b2cc0", "#9a48ec", "#c684ff", "#ecc8ff", "#ffffff"],
};
const schoolRamp = (spell) => SCHOOL_RAMP[spell.school] ?? SCHOOL_RAMP.arcane;
