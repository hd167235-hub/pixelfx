// The wizard you play.
//
// He isn't a hand-drawn sprite: he's the same 3D rig the library uses for its fighting characters
// (src/core/rig.js), posed here, shaded into a mage's palette and pre-rendered into one texture per pose.
// That means the little guy is a real skeleton — you can pose him for a cast, a walk, a stagger — and the
// look stays consistent with the rest of pixelfx.

import { posed, createFrame, composite, PAL, hex, clamp, luma } from "../../../src/core/index.js";

// the wizard's own ramp: deep indigo robe, teal trim, warm skin. Dark to light.
export const MAGE_RAMP = ["#0d0a1c", "#1b1436", "#2c2058", "#433078", "#5c4496", "#7c63b4", "#a08cd0", "#cfc2ec", "#f4efff"];
const SKIN = ["#3a1f22", "#6b3a30", "#a35d40", "#d08c62", "#f0b98a"];
const STAFF = ["#1a120c", "#2e2014", "#4a341e", "#6b4a28"];

// the poses the game uses
export const POSES = {
  stand: { lean: 1, fx: 3, fy: -20, bx: 9, by: -20, ffx: 3, fbx: -2 },
  walk1: { lean: 3, fx: 6, fy: -18, bx: 2, by: -24, ffx: 6, fbx: -6, ffy: -4 },
  walk2: { lean: 3, fx: 1, fy: -23, bx: 8, by: -16, ffx: -2, fbx: 6, ffy: -4 },
  gather: { lean: -3, crouch: 2, fx: 10, fy: -27, bx: 14, by: -28, ffx: 3, fbx: -3 },
  push: { lean: 7, crouch: 3, fx: 17, fy: -24, bx: 16, by: -26, ffx: 5, fbx: -5 },
  hold: { lean: -1, fx: 4, fy: -32, bx: 13, by: -30, ffx: 3, fbx: -3 },
  hurt: { lean: -7, crouch: 5, fx: -4, fy: -17, bx: 11, by: -23, ffx: 1, fbx: -5 },
  dash: { lean: 10, crouch: 5, fx: 13, fy: -19, bx: -7, by: -22, ffx: 8, fbx: -6 },
  sit: { lean: 2, crouch: 9, fx: 4, fy: -16, bx: 10, by: -16, ffx: 5, fbx: -1, ffy: -2 },
};

const W = 96, H = 96, OX = -W / 2, OY = -80;   // world px (0,0) sits at column 48, row 80

const cache = new Map();

/**
 * Render a pose into an RGBA buffer: { w, h, rgba } (row 0 is the top, the feet are at column 48, row 80).
 * Pure — no canvas — so the offline tools can draw him too.
 */
export function magePixels(name = "stand") {
  const key = name;
  let out = cache.get(key);
  if (out) return out;
  const pose = POSES[name] ?? POSES.stand;
  const r = posed(pose);
  const frame = createFrame(W, H, OX, OY);
  const C = MAGE_RAMP.map(hex), S = SKIN.map(hex), K = STAFF.map(hex);
  const shade = (c) => {
    // the rig's palette is the stand-in character's greys: map its value onto the wizard's ramp
    const v = clamp(luma(c) * 1.06, 0, 0.999);
    return C[Math.floor(v * C.length)];
  };
  // His head sits at the top, his hands out in front: those are skin, everything else is robe and boots.
  const HEAD = 49;   // frame rows above this are the head
  for (let i = 0; i < r.n; i++) {
    const color = r.color[i];
    if (!color) continue;
    const x = r.xs[i] + 48, y = r.ys[i] + 80;
    if (x < 0 || y < 0 || x >= W || y >= H) continue;
    const v = luma(color);
    if (r.ink && r.ink[i]) {
      // the rig's ink line: keep it as the wizard's own dark outline
      frame.color[y * W + x] = C[0];
      continue;
    }
    const skin = y < HEAD || (Math.abs(x - (48 + (pose.fx ?? 3))) <= 2 && Math.abs(y - (80 + (pose.fy ?? -20))) <= 2);
    let c;
    if (skin) c = S[Math.max(1, Math.min(S.length - 1, Math.round(1 + v * (S.length - 2))))];
    else {
      // cloth: the rig's shading value, compressed into the robe's mid tones so he reads dark against the grass
      const k = Math.max(1, Math.min(C.length - 2, Math.round(1.2 + v * 4.6)));
      c = C[k];
      // a hem and a belt in the brighter trim
      if (y > 74 && v > 0.5) c = C[Math.min(C.length - 1, k + 2)];
    }
    frame.color[y * W + x] = c;
  }
  // a small arcane spark at the raised hand, and a soft glow round it, so the wizard half-reads as "casting"
  const handX = Math.round(48 + (pose.fx ?? 3)), handY = Math.round(80 + (pose.fy ?? -20));
  for (const [dx, dy, k] of [[0, 0, 8], [1, 0, 6], [0, -1, 7], [-1, 0, 5], [0, 1, 5], [1, -1, 8], [-1, 1, 4]]) {
    const x = handX + dx, y = handY + dy;
    if (x < 0 || y < 0 || x >= W || y >= H) continue;
    frame.color[y * W + x] = C[k];
    frame.light[y * W + x] = hex("#b98cff") & 0xffffff;
  }
  for (let dy = -3; dy <= 3; dy++)
    for (let dx = -3; dx <= 3; dx++) {
      const d = Math.hypot(dx, dy);
      if (d > 3) continue;
      const x = handX + dx, y = handY + dy;
      if (x < 0 || y < 0 || x >= W || y >= H) continue;
      const cur = frame.light[y * W + x] & 0xffffff;
      const k = Math.round((1 - d / 3.4) * 26);
      frame.light[y * W + x] = Math.max(cur, (k << 16) | (Math.round(k * 0.55) << 8) | Math.round(k * 1.6));
    }
  const rgba = new Uint8ClampedArray(W * H * 4);
  composite(frame, rgba, null);
  // trim empty rows so the texture stays small
  out = { w: W, h: H, rgba, ox: 48, oy: 80, pose };
  cache.set(key, out);
  return out;
}

export const MAGE_SIZE = { w: W, h: H, ox: 48, oy: 80 };
